"""DRAFT future one-shot replication executor. No dispatch or campaign performed by I1G.
Only usable after explicit separate approval, immutable release package, and actual
pinned-runtime regression gate; the approval receipt itself is not human authorization.
"""
import argparse, json, os, sys, time, importlib.metadata as md
from pathlib import Path
from xml.etree import ElementTree
from replication_prepare import (ROOT,FLAGS,SEEDS,COMMIT,require,read,check_digest,check_manifest,bind,make_hook,d,I,verify_case,verify_future,trace_sink,dump,sha256_file)

PLAN_SHA='6617ee08a026df073142f2859bb8ccabe04773c38894cb6c3128338e7baf4743'

def release_gate(plan,approval,tests):
    require(check_digest(plan)==PLAN_SHA,'plan identity')
    require(approval.get('approved') is True and approval.get('plan_sha256')==PLAN_SHA and approval.get('base_commit')==COMMIT,'separate explicit approval required')
    require(approval.get('budget_job_min')==10 and approval.get('purpose')=='PIMCAT-I1G-REPLICATION-ONLY','budget scope')
    require(approval.get('release_commit')==os.environ.get('GITHUB_SHA') and bool(os.environ.get('GITHUB_SHA')) and os.environ.get('GITHUB_ACTIONS')=='true','authorized frozen runner required')
    require(os.environ.get('GITHUB_REF_NAME')=='research/pimcat-i1g-replication','wrong ref')
    require(approval.get('source_manifest_sha256')==sha256_file(ROOT/'source-manifest.json'),'source manifest approval')
    require(approval.get('tests_sha256')==sha256_file(tests),'regression proof identity')
    require(approval.get('release_review_complete') is True,'release review pending')
    ts=ElementTree.parse(tests).getroot(); suites=[ts] if ts.tag=='testsuite' else ts.findall('testsuite')
    expected=ElementTree.parse(ROOT/'original-tests.xml').getroot()
    key=lambda x:(x.get('classname'),x.get('name'))
    original_names=sorted(key(x) for x in expected.iter('testcase'))
    actual_names=sorted(key(x) for x in ts.iter('testcase'))
    require(len(original_names)==49 and original_names==actual_names and all(not any(int(x.attrib.get(k,0)) for k in ('errors','failures','skipped')) for x in suites) and all(len(x)==0 or all(y.tag not in ('failure','error','skipped') for y in x) for x in ts.iter('testcase')),'target original regression must pass including SUMO smokes')
    require(sys.version_info[:2]==(3,12),'target Python 3.12')
    for x in read(ROOT/'release-audit.json')['deps']:
        require(md.version(x['requirement'].split('[',1)[0])==x['target'],'dependency drift '+x['requirement'])
    # Each suite must be rerun on the target; use a technical proof receipt
    # linked to the separately authorized release, not a simulated acceptance.
    target_dir=Path(tests).resolve().parent
    expected_files={'target-i1e.xml':ROOT/'i1e-retest.xml','target-i1f.xml':ROOT/'i1f-retest.xml','target-release.xml':ROOT/'release-tests-final.xml'}
    proof_hashes=approval.get('additional_target_proofs',{})
    for name,reference in expected_files.items():
        f=target_dir/name
        require(f.is_file() and proof_hashes.get(name)==sha256_file(f),'missing target proof '+name)
        doc=ElementTree.parse(f).getroot();orig=ElementTree.parse(reference).getroot()
        require(sorted(key(x) for x in doc.iter('testcase'))==sorted(key(x) for x in orig.iter('testcase')),'target suite identity '+name)
        require(all(y.tag not in ('failure','error','skipped') for x in doc.iter('testcase') for y in x),'target suite not green '+name)
    parity_file=target_dir/'target-real-parity.json';require(parity_file.is_file() and proof_hashes.get(parity_file.name)==sha256_file(parity_file),'missing full binding proof')
    pr=read(parity_file);check_digest(pr);old=read(ROOT/'real-parity-report.json')
    require(pr['scope']==old['scope'] and pr['commit']==COMMIT and pr['runtime']['python'].startswith('3.12.') and pr['rows']==old['rows'] and pr['parity_passed'] is True and pr['failures']==[] and pr['risk_failures']==[] and pr['risk_windows']==3330,'target full-module parity')
    check_manifest();return True

def execute(plan,approval,tests,output):
    release_gate(plan,approval,tests)
    output=Path(output).resolve();output.mkdir(mode=0o700,parents=False,exist_ok=False)
    # Atomic single-use marker in the exclusive output root. Runner release review
    # must separately prohibit a second dispatch; this local marker is not global.
    (output/'ATTEMPT').write_text(PLAN_SHA+'\n')
    modules=bind(ROOT/'repo');rows=[];traces=[];start=time.monotonic()
    tracepath=output/'traces.jsonl'
    with tracepath.open('x') as out:
        def write(t):
            line=json.dumps(t,sort_keys=True,allow_nan=False);out.write(line+'\n');out.flush();os.fsync(out.fileno());traces.append(json.loads(line))
        # First import/use of libsumo only after the separate gate and marker.
        api=d.ensure_version()
        for case in plan['cases']:
            require(time.monotonic()-start<120,'campaign cap reached')
            sink=trace_sink(case,write);hook=make_hook(modules,sink)
            r=d.case(api,output/f"case-{case['family']}-{case['seed']}",case['family'],case['seed'],I.POLICIES,select_fn=hook,canonical_network=True)
            dump(output/f"result-{case['family']}-{case['seed']}.json",r)
            verify_case(r,case,[t for t in traces if t['case_id']==case['case_id']]); rows.append(r)
    require(time.monotonic()-start<=120,'campaign cap exceeded')
    result=verify_future(plan,rows,traces);dump(output/'verification.json',result);return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--execute-authorized',action='store_true');p.add_argument('--approval',type=Path);p.add_argument('--target-junit',type=Path);p.add_argument('--output',type=Path);a=p.parse_args()
    if not(a.execute_authorized and a.approval and a.target_junit and a.output):p.error('NOT RELEASED: separate explicit authorization and target proof required')
    execute(read(ROOT/'replication-plan.json'),read(a.approval),a.target_junit,a.output)
