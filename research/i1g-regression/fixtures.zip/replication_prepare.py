"""I1G offline preparation and verification. No SUMO execution on import or prepare.
A future run is deliberately NOT released; this module builds immutable demand
commitments and verifies results of a separately authorized experiment only.
"""
from pathlib import Path
from collections import Counter
import hashlib, json, tempfile, sys, zipfile, importlib.metadata as metadata, ast, re, math
import yaml
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'repo/backend'),str(ROOT/'i1f')]
from real_parity import check_manifest
from harness_hook import bind, make_hook, blob
from src.benchmarking import si11d_sumo as d, pimcat_i1d_order_x as I
from src.archive.store import fingerprint
from src.validation.io import sha256_file
SEEDS=(15700,15701,15702,15703)
COMMIT='7ce7a098fddfe2f3650149b55570389a70880ea8'
PLAN_SHA='6617ee08a026df073142f2859bb8ccabe04773c38894cb6c3128338e7baf4743'
FLAGS=dict(candidate_promoted=False,physical_actuation=False,operationally_validated=False,x_validated_for_real_traffic=False,commercial_demo_authorized=False,operational_decision='abstain',c3_independent_precision='BLOCKED_BY_INDEPENDENT_ANNOTATION',phase_b='DEFERRED',final_acceptance='PENDING_HUMAN',field_status='FIELD_BLOCKED',obs_mobile='SUSPENDED',fr_perf_02c='NO_ELIGIBLE_CANDIDATE',fr_perf_02d='BLOCKED')
ARTIFACTS={15029745572:'5b644656ed6f8e96a6fad3e0bdaeaa1af0759a754094165b97588a7124aa969c',15028982222:'d8c443c530a4295b2814236d430e8c5d7030d2963e592cb5ec5fe042caac4fc9',15029547716:'4957e94109ee07d7b307327a3a1a04a5d00166e07951abb9c9b07dfb83445ebb',15032305730:'1bd9c4b1ac502a736be4e089798720d798ecf8205d9b02d3c19758cb5e3018cf'}

def require(ok,msg):
    if not ok:raise ValueError(msg)

def dump(path,obj):
    with Path(path).open('x',encoding='utf-8') as f:json.dump(obj,f,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False);f.write('\n')

def read(path):return json.loads(Path(path).read_text())

def check_digest(r,key='report_sha256'):
    b=dict(r); h=b.pop(key,None);require(h==fingerprint(b),'canonical digest');return h

def seed_literals(p):
    out={}
    for n in ast.parse(p.read_text()).body:
        if not isinstance(n,(ast.Assign,ast.AnnAssign)):continue
        targets=n.targets if isinstance(n,ast.Assign) else [n.target]
        names=[x.id for x in targets if isinstance(x,ast.Name) and x.id in ('SEEDS','TRAIN','TEST')]
        if not names:continue
        v=n.value
        if isinstance(v,ast.Call) and isinstance(v.func,ast.Name) and v.func.id=='tuple' and len(v.args)==1:
            v=v.args[0]
            if isinstance(v,ast.Call) and isinstance(v.func,ast.Name) and v.func.id=='range':vals=list(range(*(ast.literal_eval(a) for a in v.args)))
            else: vals=list(ast.literal_eval(v))
        else:vals=list(ast.literal_eval(v))
        for name in names:out[name]=vals
    return out

def audit(artifact_root=None):
    artifact_root=Path(artifact_root) if artifact_root is not None else (ROOT/'historical' if (ROOT/'historical').is_dir() else Path('/mnt/data'))
    check_manifest(); sources=[]; seeds=set(); archive=[]
    for p in sorted((ROOT/'repo/backend/src/benchmarking').glob('*.py')):
        decl=seed_literals(p); found=sorted({s for vals in decl.values() for s in vals})
        seeds.update(found);sources.append({'file':p.name,'git_blob':blob(p.read_bytes()),'seed_declarations':decl,'proposed_literal_occurs':any(str(s) in p.read_text() for s in SEEDS)})
    for id,digest in ARTIFACTS.items():
        p=artifact_root/f'github-actions-artifact-{id}.zip'
        with zipfile.ZipFile(p) as z:
            require(z.testzip() is None,'artifact CRC');r=json.loads(z.read('study.json'))
        require(check_digest(r,'result_sha256')==digest,'historical digest')
        found={s for k,v in r.items() if k in ('seeds','training_seeds','test_seeds') for s in v};seeds.update(found)
        if id==15032305730:require(I.verify(r) is False,'I1D negative must remain')
        archive.append(dict(artifact=id,zip_sha256=sha256_file(p),canonical_sha256=digest,seeds=sorted(found),research_gate=r.get('research_gate_passed'),i1d_original_verify='NEGATIVE_PRESERVED' if id==15032305730 else 'NOT_REEVALUATED'))
    require(not seeds.intersection(SEEDS),'seed collision');require(not any(x['proposed_literal_occurs'] for x in sources),'seed literal already present')
    workflows=[]
    for f in sorted((ROOT/'repo/.github/workflows').glob('*.yml')):
        a=yaml.load(f.read_text(),Loader=yaml.BaseLoader);tr=a['on'];events=list(tr) if isinstance(tr,dict) else tr if isinstance(tr,list) else [tr]
        workflows.append(dict(path=f.name,blob=blob(f.read_bytes()),events=events,trigger=tr,job_timeouts={k:v.get('timeout-minutes') for k,v in a.get('jobs',{}).items()}))
    require(len(workflows)==37,'workflow inventory');require(all('issue_comment' not in x['events'] for x in workflows),'issue comment trigger')
    deps=[]
    for f in (ROOT/'repo/backend/requirements.txt',ROOT/'repo/backend/requirements-dev.txt'):
        for l in f.read_text().splitlines():
            if '==' not in l:continue
            pkg,target=l.split('==',1);name=pkg.split('[',1)[0]
            try:actual=metadata.version(name)
            except metadata.PackageNotFoundError:actual=None
            deps.append(dict(requirement=pkg,target=target,local=actual,match=target==actual))
    for name in ('eclipse-sumo','libsumo','sumolib','traci'):
        try:actual=metadata.version(name)
        except metadata.PackageNotFoundError:actual=None
        deps.append(dict(requirement=name,target='1.24.0',local=actual,match=actual=='1.24.0'))
    report=dict(scope='offline_read_only_release_audit',commit=COMMIT,sources=sources,historical_artifacts=archive,proposed_seeds=list(SEEDS),overlap=[],workflows=workflows,trigger_counts=dict(Counter(e for w in workflows for e in w['events'])),deps=deps,local_python=sys.version.split()[0],target_python='3.12',target_pinned_environment_verified=False,dependency_lock_complete=False,**FLAGS)
    report['report_sha256']=fingerprint(report);return report

def prepare(audit_report):
    check_digest(audit_report);require(audit_report['overlap']==[],'seed audit'); require(audit_report['commit']==COMMIT,'base commit')
    check_manifest();mods=bind(ROOT/'repo');cases=[]
    with tempfile.TemporaryDirectory(prefix='i1g-demand-commitments-') as folder:
        for f in d.FAMILIES:
            for s in SEEDS:
                rates,rows=d.demand(f,s);require((rates,rows)==d.demand(f,s),'demand reproducibility')
                out=Path(folder)/'demand.xml';d.write_routes(out,rows); dh=sha256_file(out)
                case={'family':f,'seed':s,'demand_sha256':dh,'scheduled':len(rows),'nominal_rates':list(rates)}
                case['case_id']=fingerprint(case); cases.append(case)
    require(len(cases)==32 and len({x['case_id'] for x in cases})==32,'case count')
    require(len({x['demand_sha256'] for x in cases})==32,'duplicate exact demand')
    plan=dict(scope='prospective_replication_not_authorized_not_executed',commit=COMMIT,source_manifest_sha256=sha256_file(ROOT/'source-manifest.json'),audit_sha256=audit_report['report_sha256'],original_seeds=list(I.SEEDS),seeds=list(SEEDS),families=list(d.FAMILIES),policies=list(I.POLICIES),cases=cases,trajectories=160,cycles=640,order_traces=128,horizon_seconds=d.HORIZON,green_ticks_per_cycle=52,transition_ticks_per_cycle=8,receiving='UNKNOWN',sumo_version=d.VERSION,python_target='3.12',job_min_proposed=10,authorized=False,executed=False,**FLAGS)
    plan['report_sha256']=fingerprint(plan);return plan

def verify_trace(t,case,plan_row):
    require(t.get('case_id')==case['case_id'] and t.get('family')==case['family'] and t.get('seed')==case['seed'],'trace case identity')
    require(t.get('policy')=='order_x' and t.get('cycle_start') in range(0,240,60),'trace cycle/policy')
    require(t.get('mismatches')==[] and t.get('physical_actuation') is False and t.get('candidate_promoted') is False and t.get('operational_decision')=='abstain','trace parity/boundary')
    require(t.get('diagnostic',{}).get('receiving_envelope') is None and t['diagnostic'].get('receiving_space') is None and t['diagnostic'].get('prospective_joint') is False,'receiving unknown')
    require(all(re.fullmatch('[a-f0-9]{64}',t.get(k,'')) for k in ('snapshot_sha256','engine_result_sha256')),'trace digest shape')
    require(t['actual']==t['expected'] and len(t['groups'])==2,'trace decision/group identity')
    require(t['green_budget_by_label']==t['alternate_green_budget_by_label'] and sum(t['green_budget_by_label'])==60 and t['green_budget_by_label'][2]==8,'matched green budget')
    actual=t['actual']; require(actual[1]==plan_row['reason'],'trace reason')
    # A None action is a recorded fallback, never an operational approval.
    if actual[0] is not None:require(list(actual[0])==[plan_row['first'],plan_row['window']],'trace action')
    else:require(plan_row['first']==t['cycle_start']//60%2 and plan_row['window']==26,'fallback accounting')

def trace_sink(case,write):
    def sink(trace):
        enriched={**trace,'case_id':case['case_id'],'family':case['family'],'seed':case['seed']}
        write(enriched)
    return sink

def verify_case(row,case,traces):
    require((row['family'],row['seed'],row['scheduled'],row['demand_sha256'])==(case['family'],case['seed'],case['scheduled'],case['demand_sha256']),'case/demand identity')
    require(set(row['metrics'])==set(I.POLICIES),'policy set')
    require(bool(re.fullmatch('[a-f0-9]{64}',row['network_sha256'])),'network digest')
    require(list(row['nominal_rates'])==case['nominal_rates'] and type(row['scheduled']) is int and row['scheduled']>=0,'case nominal inputs')
    for p,m in row['metrics'].items():
        require(m['runtime_version'].split()[-1]==d.VERSION,'runtime')
        require(all(type(m[k]) in (int,float) and math.isfinite(m[k]) and m[k]>=0 for k in d.FIELDS),'metric domain')
        require(all(type(m[k]) is int and m[k]>=0 for k in ('scheduled','inserted','uninserted','remaining_network','departed_network','fallbacks','colliding_vehicle_events','teleports')),'accounting domain')
        require(m['scheduled']==row['scheduled']==m['inserted']+m['uninserted'],'insertion conservation')
        require(m['inserted']==m['departed_network']+m['remaining_network'],'vehicle conservation')
        require(sum(m['green_ticks'])==52*4 and min(m['green_ticks'])>=12*4,'green budget')
        require(len(m['plans'])==4,'plan count')
        require(all(type(x['first']) is int and x['first'] in (0,1) and type(x['window']) is int and 12<=x['window']<=40 for x in m['plans']),'plan domain')
        totals=[0,0]
        for x in m['plans']:totals[x['first']]+=x['window'];totals[1-x['first']]+=52-x['window']
        require(totals==m['green_ticks'],'plan/green conservation')
    require(len(traces)==4 and {t['cycle_start'] for t in traces}=={0,60,120,180},'missing/duplicate traces')
    tr=sorted(traces,key=lambda x:x['cycle_start']); plans=row['metrics']['order_x']['plans']
    for t,x in zip(tr,plans):verify_trace(t,case,x)
    require(sum(t['actual'][0] is None for t in tr)==row['metrics']['order_x']['fallbacks'],'fallback count')

def verify_future(plan,rows,traces):
    """Verification only; does not run a campaign. Keep original assess gates."""
    require(check_digest(plan)==PLAN_SHA,'frozen plan digest');require(plan['scope']=='prospective_replication_not_authorized_not_executed','frozen plan')
    require(len(rows)==32 and len(traces)==128,'campaign incomplete')
    lookup={(x['family'],x['seed']):x for x in rows};require(len(lookup)==32,'duplicate cases')
    require({(x['family'],x['seed']) for x in plan['cases']}==set(lookup),'unexpected seeds/families')
    for case in plan['cases']:
        verify_case(lookup[(case['family'],case['seed'])],case,[t for t in traces if t['case_id']==case['case_id']])
    overall,cohorts,families,passed=I.assess(rows)
    result=dict(scope='verification_of_future_synthetic_results_not_field',overall=overall,cohorts=cohorts,families=families,research_gate_passed=passed,engineering_gate_passed=all(not (m['colliding_vehicle_events'] or m['teleports']) for x in rows for m in x['metrics'].values()),plan_sha256=plan['report_sha256'],**FLAGS)
    result['report_sha256']=fingerprint(result);return result

if __name__=='__main__':
    a=audit();dump(ROOT/'release-audit.json',a);plan=prepare(a);dump(ROOT/'replication-plan.json',plan)
    print('PREPARED ONLY',len(a['workflows']),len(a['sources']),len(plan['cases']),plan['trajectories'],plan['report_sha256'])
