"""I1G test-only fixtures; not an executed campaign or new scientific result."""
import json,copy,sys
from pathlib import Path
from collections import deque
import pytest
import replication_prepare as r
import replication_executor as e
from harness_hook import bind,make_hook
ROOT=Path(__file__).resolve().parent

@pytest.fixture(scope='module')
def mods():return bind(ROOT/'repo')
@pytest.fixture(scope='module')
def plan():return r.read(ROOT/'replication-plan.json')

@pytest.mark.parametrize('family',tuple(r.d.FAMILIES))
def test_harness_call_shape(mods,family):
    # Nominal geometry proxy only; no generated network or simulator. Actual
    # harness supplies initial pair q=0 and current halted queue birth ticks.
    length,rates,_=r.d.FAMILIES[family];cap=int(length/7.5);count=0
    for a in (rates,rates[::-1]):
        pair=((0,a[0],r.d.NOMINAL_SERVICE,cap),(0,a[1],r.d.NOMINAL_SERVICE,cap))
        for t in (0,60,120,180):
            for ns in ((0,0),(1,4),(min(8,cap),min(5,cap))):
                qs=[deque([max(0,t-60)]*n) for n in ns];traces=[];h=make_hook(mods,traces.append)
                decision=h('order_x',pair,qs,t)
                assert decision==r.I.select('order_x',pair,qs,t)
                assert len(traces)==1 and traces[0]['diagnostic']['receiving_envelope'] is None
                assert not traces[0]['mismatches'] and traces[0]['green_budget_by_label']==traces[0]['alternate_green_budget_by_label']
                if decision[0] is not None:
                    states=r.d.states((0,1),decision[0]);assert len(states)==60 and sum('G' in x for x in states)==52
                count+=1
    assert count==24

@pytest.mark.parametrize('policy',tuple(r.d.POLICIES))
def test_comparator_delegation(mods,policy):
    traces=[];h=make_hook(mods,traces.append);pair=((0,.1,.5,30),(0,.3,.5,30));qs=[deque([0]),deque([0]*4)]
    assert h(policy,pair,qs,60)==r.I.select(policy,pair,qs,60) and traces==[]

def test_plan_digests_and_counts(plan):
    assert r.check_digest(plan)==e.PLAN_SHA and plan['executed'] is False and plan['authorized'] is False
    assert len(plan['cases'])==32 and plan['trajectories']==160 and plan['cycles']==640 and plan['order_traces']==128
    assert len({x['demand_sha256'] for x in plan['cases']})==32
    assert not set(plan['seeds'])&set(plan['original_seeds'])
    assert set(plan['policies'])==set(r.I.POLICIES)

def test_rebuild_same_plan(plan):assert r.prepare(r.read(ROOT/'release-audit.json'))==plan

def test_triggers():
    a=r.read(ROOT/'release-audit.json');assert len(a['workflows'])==37 and 'issue_comment' not in a['trigger_counts'];assert a['trigger_counts']=={'pull_request':36,'push':4,'workflow_dispatch':37}

def test_target_gate_blocks_local(plan,tmp_path):
    with pytest.raises(ValueError):e.release_gate(plan,{},tmp_path/'absent.xml')

def test_target_gate_no_ambient_approval(plan,tmp_path):
    approval={'approved':True,'plan_sha256':e.PLAN_SHA,'base_commit':r.COMMIT,'budget_job_min':10,'purpose':'PIMCAT-I1G-REPLICATION-ONLY'}
    with pytest.raises(ValueError):e.release_gate(plan,approval,tmp_path/'absent.xml')

def test_missing_campaign(plan):
    with pytest.raises(ValueError,match='campaign incomplete'):r.verify_future(plan,[],[])

def test_plan_tamper(plan):
    x=copy.deepcopy(plan);x['seeds'][0]=999
    with pytest.raises(ValueError,match='canonical digest'):r.check_digest(x)

def test_case_trace_identity_and_action(mods,plan):
    case=plan['cases'][0];records=[];h=make_hook(mods,r.trace_sink(case,records.append));pair=((0,.1,.5,30),(0,.3,.5,30));qs=[deque([0]),deque([0]*4)]
    action,reason=h('order_x',pair,qs,60);t=records[0];pr={'first':action[0],'window':action[1],'reason':reason};r.verify_trace(t,case,pr)
    for key,v in [('case_id','bad'),('policy','fixed_alternating'),('cycle_start',1),('mismatches',['fault']),('physical_actuation',True),('actual',([1-action[0],action[1]],reason))]:
        bad=copy.deepcopy(t);bad[key]=v
        with pytest.raises(ValueError):r.verify_trace(bad,case,pr)
    bad=copy.deepcopy(t);bad['diagnostic']['receiving_envelope']=True
    with pytest.raises(ValueError):r.verify_trace(bad,case,pr)

def test_hook_propagates_failure(mods,monkeypatch):
    import harness_hook
    monkeypatch.setattr(harness_hook,'instrument',lambda *a,**kw:((0,26),{'mismatches':['fixture divergence']}))
    got=[];hook=make_hook(mods,got.append)
    with pytest.raises(ValueError,match='parity failure'):hook('order_x',(),(),0)
    assert got[0]['mismatches']==['fixture divergence']

def test_no_sumo_import():assert 'libsumo' not in sys.modules

def test_forged_rehashed_plan(plan):
    x=copy.deepcopy(plan);x['seeds'][0]=999;x.pop('report_sha256');x['report_sha256']=r.fingerprint(x)
    with pytest.raises(ValueError,match='frozen plan digest'):r.verify_future(x,[],[])

def test_target_gate_rejects_local_skipped_suite(plan,monkeypatch):
    # Test-only simulated runner env; never invoke execute or import SUMO.
    monkeypatch.setenv('GITHUB_ACTIONS','true');monkeypatch.setenv('GITHUB_SHA','a'*40);monkeypatch.setenv('GITHUB_REF_NAME','research/pimcat-i1g-replication')
    p=ROOT/'original-tests.xml'
    approval={'approved':True,'plan_sha256':e.PLAN_SHA,'base_commit':r.COMMIT,'budget_job_min':10,'purpose':'PIMCAT-I1G-REPLICATION-ONLY','release_commit':'a'*40,'source_manifest_sha256':r.sha256_file(ROOT/'source-manifest.json'),'tests_sha256':r.sha256_file(p),'release_review_complete':True}
    with pytest.raises(ValueError,match='target original regression'):e.release_gate(plan,approval,p)

@pytest.fixture(scope='module')
def case_fixture(mods,plan):
    # Artificial schema fixture, not traffic simulation or scientific evidence.
    case=plan['cases'][0];tr=[];h=make_hook(mods,r.trace_sink(case,tr.append));pair=((0,.1,.5,30),(0,.3,.5,30));plans=[]
    for t in (0,60,120,180):
        action,reason=h('order_x',pair,[deque([0]),deque([0]*4)],t);plans.append({'first':action[0],'window':action[1],'reason':reason})
    green=[0,0]
    for p in plans:green[p['first']]+=p['window'];green[1-p['first']]+=52-p['window']
    m={k:0 for k in r.d.FIELDS};m.update(runtime_version='SUMO '+r.d.VERSION,scheduled=case['scheduled'],inserted=0,uninserted=case['scheduled'],remaining_network=0,departed_network=0,green_ticks=green,plans=plans,fallbacks=0,colliding_vehicle_events=0,teleports=0)
    row={'family':case['family'],'seed':case['seed'],'scheduled':case['scheduled'],'nominal_rates':case['nominal_rates'],'demand_sha256':case['demand_sha256'],'network_sha256':'a'*64,'metrics':{p:copy.deepcopy(m) for p in r.I.POLICIES}}
    return row,case,tr

def test_schema_only_case(case_fixture):r.verify_case(*case_fixture)
@pytest.mark.parametrize('fault',['missing_trace','bad_budget','bad_demand','negative_metric','bad_conservation','bad_reason'])
def test_invalid_case(case_fixture,fault):
    row,case,tr=copy.deepcopy(case_fixture)
    if fault=='missing_trace':tr.pop()
    elif fault=='bad_budget':row['metrics']['order_x']['green_ticks'][0]+=1
    elif fault=='bad_demand':row['demand_sha256']='0'*64
    elif fault=='negative_metric':row['metrics']['order_x'][r.d.FIELDS[0]]=-1
    elif fault=='bad_conservation':row['metrics']['order_x']['inserted']=1
    elif fault=='bad_reason':tr[0]['actual']=(tr[0]['actual'][0],'bad')
    with pytest.raises(ValueError):r.verify_case(row,case,tr)
