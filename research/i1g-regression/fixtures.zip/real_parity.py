"""Reproduce frozen I1F on exact Git source modules; no SUMO or controller."""
from pathlib import Path
from collections import Counter
import json, hashlib, math, sys, time, importlib.metadata as metadata
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'repo/backend')); sys.path.insert(0,str(ROOT/'i1f'))
import harness_hook as h
import parity as p

def read(name):return json.loads((ROOT/name).read_text())
def canonical(v):return json.loads(json.dumps(v,sort_keys=True,allow_nan=False))
def check_manifest():
    for r in read('source-manifest.json'):
        raw=(ROOT/'repo'/r['path']).read_bytes()
        if h.blob(raw)!=r['git_sha'] or hashlib.sha256(raw).hexdigest()!=r['sha256'] or len(raw)!=r['bytes']:raise ValueError('original source drift '+r['path'])
def run(output=None):
    check_manifest();mods=h.bind(ROOT/'repo'); E,R,C,I=mods
    prior=read('i1f/parity-report.json'); body=dict(prior); digest=body.pop('report_sha256');assert p.F.fingerprint(body)==digest
    frozen=read('i1f/prior/report.json');fb=dict(frozen); fd=fb.pop('report_sha256');assert p.F.fingerprint(fb)==fd
    boundaries=read('i1f/boundaries.json'); inputs=[]
    for i,r in enumerate(frozen['rows']):inputs.append(('frozen_grid',i,p.diag.Group(**r['minor']),p.diag.Group(**r['major']),r['confidence'],tuple(r['receiving_space'])))
    for b in boundaries:inputs.append(('boundary',b['id'],p.diag.Group(*b['m']),p.diag.Group(*b['M']),b.get('confidence',.95),b.get('receiving')))
    expected={(r['kind'],r['case'],r['swap']):r for r in prior['rows']}; rows=[]; failures=[]
    for kind,id,m,M,confidence,receiving in inputs:
        for swap in (False,True):
            g=[m,M];rec=receiving
            if swap:g.reverse();rec=None if receiving is None else receiving[::-1]
            t=max(240,*(x.age for x in g));qs=[[t-x.age]*x.q for x in g];pair=tuple(x.p() for x in g)
            traces=[]; hook=h.make_hook(mods,traces.append,None if rec is None else lambda *args:rec)
            key=(kind,id,swap)
            try:
                action=hook('order_x',pair,qs,t,confidence)
                assert action==I.select('order_x',pair,qs,t,confidence)
                assert len(traces)==1
                tr=traces[0];assert tr.pop('policy')=='order_x' and tr.pop('cycle_start')==t
                tr.update(case=id,swap=swap,kind=kind)
                tr=canonical(tr);old=expected[key]
                diff=[k for k in sorted(set(tr)|set(old)) if tr.get(k)!=old.get(k)]
                if diff:failures.append({'key':key,'different_fields':diff})
                rows.append(tr)
            except Exception as e:
                failures.append({'key':key,'error_type':type(e).__name__,'trace':canonical(traces)})
    pairs={ (tuple(r['diagnostic']['minor'][k] for k in ('q','a','s','cap')),tuple(r['diagnostic']['major'][k] for k in ('q','a','s','cap'))) for r in prior['rows'] }
    maxima=[0.,0.]; n=0;profile_failures=[]
    for m,M in sorted(pairs):
        orig=R.risk_profile(m,M);assert len(orig)==30
        for o in orig:
            v=p.diag.risks(m,M,o['window']); n+=1
            diff=[abs(v['major_risk']-o['major_critical_probability_assumed']),abs(v['minor_clearance']-o['minor_clearance_lower_probability_assumed'])]
            maxima=[max(a,b) for a,b in zip(maxima,diff)]
            if v['eligible']!=o['eligible'] or v['risk_x']!=o['x'] or max(diff)>1e-12:profile_failures.append({'pair':[m,M],'window':o['window'],'errors':diff})
    assert 'libsumo' not in sys.modules
    result={'scope':'real_complete_module_binding_and_selector_hook_synthetic_no_sumo','commit':'7ce7a098fddfe2f3650149b55570389a70880ea8','source_blobs':len(read('source-manifest.json')),'prior_report_sha256':digest,'comparisons':len(expected),'complete_traces':len(rows),'failures':failures,'risk_pairs':len(pairs),'risk_windows':n,'risk_max_abs_errors':maxima,'risk_failures':profile_failures,'grid_reasons':dict(Counter(r['actual'][1] for r in rows if r['kind']=='frozen_grid' and not r['swap'])),'rows':rows,'parity_passed':len(rows)==812 and not failures and not profile_failures and n==3330,'libsumo_imported':False,'physical_actuation':False,'candidate_promoted':False,'operational_decision':'abstain','runtime':{'python':sys.version.split()[0],'pydantic':metadata.version('pydantic'),'SQLAlchemy':metadata.version('SQLAlchemy')}}
    result['report_sha256']=p.F.fingerprint(result)
    with Path(output or ROOT/'real-parity-report.json').open('x') as f:json.dump(result,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
    print({k:v for k,v in result.items() if k not in ('rows','failures','risk_failures')});print('failures',len(failures),len(profile_failures)); return result
if __name__=='__main__':
    import argparse
    a=argparse.ArgumentParser();a.add_argument('--output',type=Path);args=a.parse_args()
    t=time.monotonic();r=run(args.output);print('elapsed',time.monotonic()-t);raise SystemExit(0 if r['parity_passed'] else 1)
