"""Opt-in read-only hook for an offline research harness. Never import in runtime.
Full repository binding is intentionally NOT run by this local excerpt study.
"""
from pathlib import Path
import hashlib, importlib, json
from parity import instrument

BLOBS={
 'src.optimization.engine':'9a3b609dc8c7a610741eceb912fd24ef335fd515',
 'src.optimization.contracts':'2bf631a9ceec9a6dc0b1938d029b3ccefb22d022',
 'src.queueing.contracts':'19ece52de39255de82e13a736e2a25983c820149',
 'src.analytics.contracts':'3ca5b32c7059c2454226c4e0522f1ec8c9ff0749',
 'src.archive.store':'d1a6a744b270c18f69e2a4425aa7cf6b6d27cbb6',
 'src.benchmarking.si11_counterfactual':'a750589972329dcbad599edb12ab28e34824cb21',
 'src.benchmarking.si11b_robust_x':'44f4a0b14cdce71a65ee2caaa8b2ed8bff53c033',
 'src.benchmarking.si11c_predictive_x':'7efafd28e631d86090926bfbcbf09fa04f63ce6e',
 'src.benchmarking.pimcat_i1d_order_x':'92728dc19e34a0ceb073041e9562f2d63bdb59a7',
 'src.benchmarking.si11d_sumo':'5d55e7e1fcb42d8b2db7ea5208264619fbae7cc2'}

def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def bind(root):
    """Only in an authorized offline harness; reject drift before imports."""
    root=Path(root).resolve(strict=True)
    paths={name:root/'backend'/Path(*name.split('.')).with_suffix('.py') for name in BLOBS}
    for name,path in paths.items():
        if not path.resolve().is_relative_to(root) or blob(path.read_bytes())!=BLOBS[name]:raise ValueError('repository blob drift '+name)
    modules={name:importlib.import_module(name) for name in paths}
    for name,m in modules.items():
        if Path(m.__file__).resolve()!=paths[name].resolve():raise ValueError('wrong import origin '+name)
    return tuple(modules[n] for n in ('src.optimization.engine','src.benchmarking.si11b_robust_x','src.benchmarking.si11c_predictive_x','src.benchmarking.pimcat_i1d_order_x'))

def make_hook(modules, sink, receiving=None):
    """Return I1D-compatible select_fn. Only order_x gets diagnostic trace.
    Unknown receiving is the default. A provider, if independently verified, may
    return integer free receiving space by label. No raw vehicle identifiers.
    Reject on parity failure, never replace the decision or relax a gate.
    """
    def hook(policy,pair,queues,t,confidence=.95):
        if policy!='order_x':return modules[3].select(policy,pair,queues,t,confidence)
        rec=None if receiving is None else receiving(pair,queues,t)
        decision,trace=instrument(pair,queues,t,confidence,rec,modules=modules)
        trace={**trace,"cycle_start":t,"policy":policy}
        sink(trace)
        if trace['mismatches']:raise ValueError('I1F diagnostic parity failure; preserve trace and stop')
        return decision
    return hook
