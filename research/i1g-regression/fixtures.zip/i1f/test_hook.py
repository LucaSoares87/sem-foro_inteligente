import pytest
import parity as p
from harness_hook import make_hook,bind

def test_hook_preserves_actual_and_unknown_receiving():
    mods=(p.E,p.R,p.C,p.I);records=[];h=make_hook(mods,records.append)
    pair=((1,0,.95,24),(8,.05,.45,40));queues=[[0],[0]*8]
    assert h('order_x',pair,queues,0)==p.I.select('order_x',pair,queues,0)
    assert len(records)==1 and records[0]['diagnostic']['receiving_envelope'] is None
    assert records[0]['cycle_start']==0 and records[0]['policy']=='order_x'
    assert not records[0]['diagnostic']['prospective_joint']
    assert h('demand_proportional',pair,queues,0)==p.I.select('demand_proportional',pair,queues,0)
    assert len(records)==1

def test_hook_preserves_trace_and_rejects_mismatch(monkeypatch):
    import harness_hook
    monkeypatch.setattr(harness_hook,'instrument',lambda *a,**kw:((0,26),{'mismatches':['test fault']}))
    records=[];h=make_hook((p.E,p.R,p.C,p.I),records.append)
    with pytest.raises(ValueError):h('order_x',(),(),0)
    assert records==[{'mismatches':['test fault'],'cycle_start':0,'policy':'order_x'}]

def test_binding_missing_checkout(tmp_path):
    with pytest.raises((FileNotFoundError,ValueError)):bind(tmp_path)
