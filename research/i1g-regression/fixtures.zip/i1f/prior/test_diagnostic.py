import math,json,hashlib
import pytest
from diagnostic import Group,x_parts,risks,oracle,diagnose,schedule,grid

@pytest.mark.parametrize('m,M,expected',[
 (Group(1,.5,.5,20),Group(5,.1,.7,30),0),
 (Group(1,.6,.5,20),Group(5,.1,.7,30),0),
 (Group(1,0,.5,20),Group(17,.5,.7,20),0),
 (Group(1,0,1,4),Group(5,0,.7,30),3),
 (Group(4,0,1,4),Group(5,0,.7,30),3),
 (Group(1,0,.5,20),Group(12,.5,.7,20),3),
])
def test_x(m,M,expected):assert x_parts(m,M)['x']==expected

def test_clear_30_boundary():
 m=Group(15,0,.5,40);M=Group(16,0,.5,100)
 assert x_parts(m,M)['clear']==30 and x_parts(m,M)['checks']['clear_le_30']
 assert not x_parts(Group(16,0,.5,40),Group(17,0,.5,100))['checks']['clear_le_30']

def test_headroom_floor_distinct():
 m=Group(1,0,1,20);M=Group(17,.01,.9,20)
 assert x_parts(m,M)['x']==0
 assert risks(m.p(),M.p(),12)['major_risk']>0

@pytest.mark.parametrize('w',[1,12,20,30])
@pytest.mark.parametrize('m,M',[(Group(1,0,.95,24),Group(8,.05,.45,40)),(Group(6,.15,.45,24),Group(16,.35,.95,40)),(Group(1,0,.95,24),Group(30,.35,.95,40)),(Group(1,1,0,24),Group(35,1,1,40))])
def test_oracle(m,M,w):
 r=risks(m.p(),M.p(),w);a,b=oracle(m,M,w)
 assert abs(r['major_risk']-float(a))<=1e-12
 assert abs(r['minor_clearance']-float(b))<=1e-12

def test_risk_window():
 m=Group(1,0,.95,24);M=Group(8,.05,.45,40)
 assert risks(m.p(),M.p(),30) is not None and risks(m.p(),M.p(),31) is None

def test_separate_risk_subconditions():
 m=Group(1,0,.95,24);M=Group(30,.35,.95,40);r=risks(m.p(),M.p(),12)
 assert not r['checks']['major_risk_le_5pct'] and r['checks']['minor_clearance_ge_95pct'] and not r['eligible']
 r=risks(Group(6,.15,.45,24).p(),Group(16,.35,.95,40).p(),12)
 assert r['checks']['major_risk_le_5pct'] and not r['checks']['minor_clearance_ge_95pct'] and not r['eligible']

def test_risk_quantile_cap():
 r=risks(Group(4,0,1,4).p(),Group(5,0,.95,100).p(),12)
 assert r['checks']['minor_clearance_ge_95pct'] and not r['checks']['q_le_risk_quantile'] and not r['eligible']

@pytest.mark.parametrize('conf,reason',[(.649999,'low_confidence_abstain'),(.65,'order_keep_cost_veto')])
def test_confidence(conf,reason):assert diagnose(Group(1,0,.95,24),Group(8,.05,.45,40),conf)['reason']==reason
@pytest.mark.parametrize('m,M',[(Group(0,0,.95,24),Group(8,.05,.45,40)),(Group(3,0,.95,24),Group(3,.05,.45,40))])
def test_empty_equal(m,M):assert diagnose(m,M)['reason']=='order_keep_empty_or_tie'

def test_wait_exact():
 m=Group(3,0,.95,24,120)
 b=diagnose(m,Group(8,.05,.45,40,0));w=b['green_by_group'][0]
 assert diagnose(m,Group(8,.05,.45,40,180-w-4))['checks']['major_wait']
 assert not diagnose(m,Group(8,.05,.45,40,181-w-4))['checks']['major_wait']

def test_receiving_unknown_and_boundary():
 m=Group(3,0,.95,24,120);M=Group(8,.05,.45,40)
 x=diagnose(m,M);w,W=x['green_by_group'];assert x['receiving_envelope'] is None and not x['prospective_joint']
 assert diagnose(m,M,receiving=(w,W))['receiving_envelope']
 assert not diagnose(m,M,receiving=(w-1,W))['receiving_envelope']
 assert not diagnose(m,M,receiving=(w,W-1))['receiving_envelope']

def test_equal_budget_and_abstention():
 for r in grid():
  w,W=r['green_by_group'];a=schedule(0,w);b=schedule(1,W)
  assert len(a)==len(b)==60 and a.count(None)==b.count(None)==8 and a.count(0)==b.count(0)==w and a.count(1)==b.count(1)==W
  assert r['operational_decision']=='abstain' and r['physical_actuation'] is False and r['candidate_promoted'] is False
  assert r['original_formula_eligible']==all(r['checks'].values())

def test_report_reproducible():
 r=json.load(open('report.json'));h=r.pop('report_sha256');assert hashlib.sha256(json.dumps(r,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()==h
 assert r['rows']==json.loads(json.dumps(list(grid())))

@pytest.mark.parametrize('args',[(1,float('nan'),.8,20),(1,0,1.1,20),(-1,0,.8,20),(1,0,.8,0),(True,0,.8,20)])
def test_invalid(args):
 with pytest.raises(ValueError):Group(*args)

def test_unordered():
 with pytest.raises(ValueError):diagnose(Group(4,0,.9,20),Group(1,0,.9,20))

def test_invalid_receiving():
 with pytest.raises(ValueError):diagnose(Group(1,0,.9,20),Group(4,0,.9,20),receiving=(-1,20))
