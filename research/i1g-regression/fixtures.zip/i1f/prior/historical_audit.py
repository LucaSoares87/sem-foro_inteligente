"""Offline descriptive audit of frozen PIMCAT I1 evidence, no simulator or control."""
import argparse, hashlib, json, math, zipfile
from collections import Counter
from pathlib import Path
from statistics import fmean
SPECS = {
 'I1A': (15029745572,'5b644656ed6f8e96a6fad3e0bdaeaa1af0759a754094165b97588a7124aa969c',24,120,0),
 'I1B': (15028982222,'d8c443c530a4295b2814236d430e8c5d7030d2963e592cb5ec5fe042caac4fc9',32,192,16),
 'I1C': (15029547716,'4957e94109ee07d7b307327a3a1a04a5d00166e07951abb9c9b07dfb83445ebb',24,144,0),
 'I1D': (15032305730,'1bd9c4b1ac502a736be4e089798720d798ecf8205d9b02d3c19758cb5e3018cf',32,160,0),
}
# Named comparisons and directions frozen for this retrospective analysis. Not a new scientific gate.
PAIRS={
'I1A': [('advance_only','compatible'),('advance_only','predictive_xp')],
'I1B': [('calibrated_eta','adaptive_eta'),('calibrated_eta_storage','adaptive_eta_storage')],
'I1C': [('receiving_pressure','global_pressure'),('receiving_storage','global_storage')],
'I1D': [('order_x','demand_proportional'),('order_x','fixed_alternating'),('order_x','predictive_x'),('order_x','predictive_no_x')],
}
METRICS={
'I1A': {'a_stops':-1,'person_area':-1,'pedestrian_max_wait':-1,'vehicle_max_wait':-1,'pedestrians_completed':1,'vehicles_exited':1,'pedestrian_deadline_violations':-1,'vehicle_deadline_violations':-1,'vehicles_uninserted':-1,'pedestrians_uninserted':-1,'critical_exposure':-1},
'I1B': {'eta_coverage':1,'eta_mae_seconds':-1,'person_area':-1,'mean_corridor_stops':-1,'mean_corridor_travel_seconds':-1,'corridor_speed_cv':-1,'corridor_exited':1,'vehicle_uninserted':-1,'vehicle_deadline_violations':-1,'pedestrian_deadline_violations':-1,'pedestrian_max_wait':-1,'vehicle_max_wait':-1,'pedestrian_completed':1,'vehicle_exited':1,'critical_exposure':-1},
'I1C': {'critical_entries':-1,'critical_exposure':-1,'person_area':-1,'vehicle_area':-1,'vehicle_exited':1,'vehicle_uninserted':-1,'pedestrian_completed':1,'pedestrian_uninserted':-1,'vehicle_deadline_violations':-1,'pedestrian_deadline_violations':-1,'vehicle_max_wait':-1,'pedestrian_max_wait':-1},
'I1D': {'queue_area_with_pending_vehicle_seconds':-1,'departed_network':1,'uninserted':-1,'pending_vehicle_seconds':-1,'critical_occupancy_exposure_vehicle_seconds':-1,'max_accumulated_stopped_or_pending_seconds':-1},
}
FLAGS={'candidate_promoted':False,'physical_actuation':False,'operationally_validated':False,'commercial_demo_authorized':False,'operational_decision':'abstain','c3_independent_precision':'BLOCKED_BY_INDEPENDENT_ANNOTATION'}
def require(v, msg):
    if not v: raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(d):return sha(json.dumps(d,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def read_study(folder,study):
    aid,expected,n,ev,train=SPECS[study];p=folder/f'github-actions-artifact-{aid}.zip'
    with zipfile.ZipFile(p) as z:
        require(z.testzip() is None,'ZIP CRC');d=json.loads(z.read('study.json'))
    observed=d.pop('result_sha256');require(observed==expected==canonical(d),'report digest');d['result_sha256']=observed
    require(all(d.get(k)==v for k,v in FLAGS.items()),'scope flags')
    require(len(d['rows'])==d['cases']==n and len(d['training'])==train if study=='I1B' else len(d['rows'])==d['cases']==n,'case count')
    require(len({(x['family'],x['seed']) for x in d['rows']})==n,'duplicate case')
    require(all(set(x['metrics'])==set(d['policies']) for x in d['rows']),'missing policy')
    require(all(len(x['demand_sha256'])==64 and len(x['network_sha256'])==64 for x in d['rows']),'identity')
    require(n*len(d['policies'])==ev and (d['test_trajectories']==ev and d['training_trajectories']==train if study=='I1B' else d['trajectories']==ev),'trajectory count')
    if study=='I1B':require(not ({x['seed'] for x in d['training']} & {x['seed'] for x in d['rows']}),'train/test overlap')
    return d,{'artifact_id':aid,'zip_sha256':sha(p.read_bytes()),'result_sha256':observed,'cases':n,'evaluation_trajectories':ev,'calibration_trajectories':train,'original_gate':d['research_gate_passed']}
def value(m,k):
    v=m[k]
    if v is None:return None
    require(type(v) in (int,float) and math.isfinite(v),'invalid metric')
    return v
def pair(rows,c,b,metrics):
    stats={};signs=[]
    for r in rows:
        row=[]
        for k,direction in metrics.items():
            x,y=value(r['metrics'][c],k),value(r['metrics'][b],k)
            if x is not None and y is not None:row.append((k,x,y,(x-y)*direction))
        signs.append(row)
    for k in metrics:
        vals=[(x,y,s) for row in signs for key,x,y,s in row if key==k]
        stats[k]={'n':len(vals),'missing':len(rows)-len(vals),'better':sum(s>0 for x,y,s in vals),'equal':sum(s==0 for x,y,s in vals),'worse':sum(s<0 for x,y,s in vals),'mean_candidate':fmean(x for x,y,s in vals) if vals else None,'mean_baseline':fmean(y for x,y,s in vals) if vals else None,'mean_delta':fmean(x-y for x,y,s in vals) if vals else None}
    joint=Counter()
    for row in signs:
        s=[v for k,x,y,v in row];joint['incomplete' if len(s)!=len(metrics) else 'mixed' if any(x>0 for x in s) and any(x<0 for x in s) else 'better_no_worse' if any(x>0 for x in s) else 'worse_no_better' if any(x<0 for x in s) else 'equal']+=1
    return {'metrics':stats,'joint_descriptive':dict(joint)}
def false_leaves(d,p=''):
    if isinstance(d,dict):return [v for k,x in d.items() for v in false_leaves(x,p+'/'+k)]
    return [p] if d is False else []
def order_detail(d):
    c='order_x';b='demand_proportional';f={};count=Counter();same=0;diff=[]
    for r in d['rows']:
        a=r['metrics'][c];m=r['metrics'][b];family=r['family'];f.setdefault(family,Counter());require(len(a['plans'])==len(m['plans'])==4,'cycle count')
        require(a['scheduled']==m['scheduled']==r['scheduled'],'demand conservation')
        for k in (c,b):
            x=r['metrics'][k];require(x['scheduled']==x['inserted']+x['uninserted'] and x['inserted']==x['departed_network']+x['remaining_network'],'vehicle conservation')
        for x,y in zip(a['plans'],m['plans']):
            reason=x['reason'];count[reason]+=1;f[family][reason]+=1
            if (x['first'],x['window'])==(y['first'],y['window']):same+=1
            else:diff.append({'family':family,'seed':r['seed'],'candidate':x,'baseline':y})
    require(dict(count)==d['overall']['decision_reasons'],'reason reconciliation')
    return {'cycles':sum(count.values()),'identical_order_and_window':same,'reasons':dict(count),'families':{k:dict(v) for k,v in f.items()},'changed_plans':diff,'nonempty_unequal_cycles':sum(count.values())-count['order_keep_empty_or_tie'],'original_improvement_vs_proportional':d['overall']['improvement_vs_proportional']}
def run(folder):
    out={'scope':'retrospective_descriptive_synthetic_only','no_new_simulation':True,'candidate_promoted':False,'physical_actuation':False,'operational_decision':'abstain','studies':{}}
    for study in SPECS:
        d,meta=read_study(folder,study);rows=d['rows'];families=sorted({r['family'] for r in rows});res={'provenance':meta,'comparisons':{},'original_false_boolean_paths':false_leaves(d.get('gates',d.get('overall',{}).get('gates',{})))}
        for c,b in PAIRS[study]:
            res['comparisons'][c+' vs '+b]={'overall':pair(rows,c,b,METRICS[study]),'families':{f:pair([r for r in rows if r['family']==f],c,b,METRICS[study]) for f in families}}
        if study=='I1D':res['order_detail']=order_detail(d)
        out['studies'][study]=res
    out['counts']={k:sum(s['provenance'][k] for s in out['studies'].values()) for k in ('cases','evaluation_trajectories','calibration_trajectories')};out['report_sha256']=canonical(out);return out
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();d=run(a.inputs);a.out.write_text(json.dumps(d,sort_keys=True,indent=2,allow_nan=False)+'\n');print(d['counts'],d['report_sha256'])
