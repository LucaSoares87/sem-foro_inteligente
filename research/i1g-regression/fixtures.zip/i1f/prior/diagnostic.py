"""Offline synthetic state diagnostics, no controller. Source-derived formulas, not runtime imports."""
from dataclasses import dataclass, asdict
from functools import lru_cache
from fractions import Fraction
from math import floor, comb, isfinite
from itertools import product
from collections import Counter
import hashlib,json
from pathlib import Path

@dataclass(frozen=True)
class Group:
    q:int; a:float; s:float; cap:int; age:int=0
    def __post_init__(self):
        if type(self.q)!=int or type(self.cap)!=int or type(self.age)!=int or not (0<=self.q<=200 and 1<=self.cap<=200 and self.q<=2*self.cap and 0<=self.age<=86400):raise ValueError('group state')
        if any(type(v) not in (int,float) or not isfinite(v) or not 0<=v<=1 for v in (self.a,self.s)):raise ValueError('Bernoulli domain')
    def p(self):return self.q,self.a,self.s,self.cap

def x_parts(m,M):
    net=m.s-m.a; head=max(0.,.85*M.cap-M.q)
    budget=56 if M.a<=1e-9 else head/M.a-4
    cap=floor(.85*m.cap)
    x=min(cap,max(0,floor(net*max(0.,budget)))) if net>0 else 0
    clear=m.q/net if net>0 else None
    return dict(net=net,headroom=head,time_budget=budget,minor_storage_cap=cap,x=x,clear=clear,
       checks={'net_positive':net>0,'q_le_x':m.q<=x,'clear_plus_transition_le_60':clear is not None and clear+4<=60,'clear_le_30':clear is not None and clear<=30})

def step(dist, probs):
    out={}
    for k,v in dist.items():
        for inc,p in probs:
            if p:out[k+inc]=out.get(k+inc,0.)+v*p
    return out

@lru_cache(maxsize=512)
def risks(mp, Mp, w):
    if not 1<=w<=30:return None
    q,a,s,cap=mp; Q,A,_,C=Mp
    a=min(1.,a+.05);s=max(0.,s-.05);A=min(1.,A+.05)
    head=floor(.85*C)-Q
    arr={0:1.};net={0:1.}
    for _ in range(w+4):arr=step(arr,((0,1-A),(1,A)))
    for _ in range(w):net=step(net,((-1,a*(1-s)),(0,a*s+(1-a)*(1-s)),(1,(1-a)*s)))
    risk=sum(v for k,v in arr.items() if k>head)
    clear=sum(v for k,v in net.items() if k>=q)
    x=max((k for k in range(min(w,floor(.85*cap))+1) if sum(v for n,v in net.items() if n>=k)>=.95-1e-12),default=0)
    checks={'major_risk_le_5pct':risk<=.05+1e-12,'minor_clearance_ge_95pct':clear>=.95-1e-12,'q_le_risk_quantile':q<=x}
    return dict(major_risk=risk,minor_clearance=clear,raw_risk_x=x,risk_x=x if checks['major_risk_le_5pct'] else 0,checks=checks,eligible=all(checks.values()))

def binomial(n,p):return [comb(n,k)*p**k*(1-p)**(n-k) for k in range(n+1)]
def oracle(m,M,w):
    # Independent exact rational binomial marginals, not tick convolution.
    a=min(Fraction(1),Fraction(str(m.a))+Fraction(1,20));s=max(Fraction(0),Fraction(str(m.s))-Fraction(1,20));A=min(Fraction(1),Fraction(str(M.a))+Fraction(1,20))
    arrivals=binomial(w,a);service=binomial(w,s);major=binomial(w+4,A)
    risk=sum(p for k,p in enumerate(major) if k>floor(Fraction(85,100)*M.cap)-M.q)
    clear=sum(p*q for i,p in enumerate(arrivals) for j,q in enumerate(service) if j-i>=m.q)
    return risk,clear

def schedule(first,w):return (first,)*w+(None,)*4+(1-first,)*(52-w)+(None,)*4

def forecast(pair,first,w,stress):
    a=[min(1.,p.a+stress) for p in pair];s=[max(0.,p.s-stress) for p in pair];caps=[p.cap for p in pair];q=[float(p.q) for p in pair]
    area=critical=overflow=imbalance=0.
    for active in schedule(first,w):
        for g in (0,1):q[g]=max(0.,q[g]+a[g]-(s[g] if active==g else 0.))
        area+=sum(q);critical+=sum(max(0.,q[g]-.85*caps[g]) for g in (0,1));overflow+=sum(max(0.,q[g]-caps[g]) for g in (0,1));imbalance+=abs(q[0]/caps[0]-q[1]/caps[1])
    ages=[p.age for p in pair]
    return area+4*critical+15*overflow+imbalance+2*max(ages[first],ages[1-first]+w+4)

def diagnose(m,M,confidence=.95,receiving=None):
    if type(confidence) not in (int,float) or not isfinite(confidence) or not 0<=confidence<=1:raise ValueError('confidence')
    if m.q>M.q:raise ValueError('expected ordered groups')
    p=(m,M);d=[(g.q+60*g.a)/max(.05,g.s) for g in p]
    wm=max(12,min(40,round(52*d[1]/max(1e-9,sum(d)))));w=52-wm
    x=x_parts(m,M);risk=risks(m.p(),M.p(),w)
    costs=[]
    for stress in (0.,.05):
        base=forecast(p,1,wm,stress);alt=forecast(p,0,w,stress)
        costs.append(dict(stress=stress,base=base,alt=alt,gain=(base-alt)/base if base>0 else None,passed=base>0 and alt<=.95*base))
    checks={'confidence':confidence>=.65,'positive_unequal':0<m.q<M.q,'x_feasible':all(x['checks'].values()),'risk_window':risk is not None,'risk':risk is not None and risk['eligible'],'major_wait':M.age+w+4<=180,'cost_nominal':costs[0]['passed'],'cost_stress':costs[1]['passed']}
    if not checks['confidence']:reason='low_confidence_abstain'
    elif not checks['positive_unequal']:reason='order_keep_empty_or_tie'
    elif not checks['x_feasible']:reason='order_keep_x_veto'
    elif not (checks['risk_window'] and checks['risk']):reason='order_keep_risk_veto'
    elif not checks['major_wait']:reason='order_keep_wait_veto'
    elif not (checks['cost_nominal'] and checks['cost_stress']):reason='order_keep_cost_veto'
    else:reason='order_minor_first'
    # Prospective diagnostics only. Unobserved receiving space is not assumed clear.
    if receiving is not None and (len(receiving)!=2 or any(type(x)!=int or x<0 for x in receiving)):raise ValueError('receiving')
    receive=None if receiving is None else receiving[0]>=w and receiving[1]>=wm
    base_wait=[m.age+wm+4,M.age];alt_wait=[m.age,M.age+w+4]
    fair=max(alt_wait)<=max(base_wait)
    return dict(minor=asdict(m),major=asdict(M),confidence=confidence,green_by_group=[w,wm],checks=checks,x=x,risk=risk,costs=costs,major_wait_margin=180-(M.age+w+4),reason=reason,original_formula_eligible=reason=='order_minor_first',receiving_space=receiving,receiving_envelope=receive,base_wait_proxy=base_wait,alt_wait_proxy=alt_wait,fairness_no_increase_max_proxy=fair,prospective_joint=reason=='order_minor_first' and receive is True and fair,operational_decision='abstain',physical_actuation=False,candidate_promoted=False)

def grid():
    for q,Q,a,s,A,S,age,Age in product((1,3,6),(8,16),(0,.15),(.45,.95),(.05,.35),(.45,.95),(0,120),(0,160)):
        yield diagnose(Group(q,a,s,24,age),Group(Q,A,S,40,Age),receiving=(40,40))

def main():
    rows=list(grid());assert len(rows)==384
    report={'scope':'synthetic_formula_diagnostic_not_runtime','rows':rows,'first_reasons':dict(Counter(r['reason'] for r in rows)),'all_failed_checks':dict(Counter(k for r in rows for k,v in r['checks'].items() if not v)),'eligible':sum(r['original_formula_eligible'] for r in rows),'joint':sum(r['prospective_joint'] for r in rows),'physical_actuation':False,'candidate_promoted':False,'operational_decision':'abstain'}
    report['report_sha256']=hashlib.sha256(json.dumps(report,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    Path('report.json').write_text(json.dumps(report,indent=2,sort_keys=True,allow_nan=False)+'\n');print({k:v for k,v in report.items() if k!='rows'})
if __name__=='__main__':main()
