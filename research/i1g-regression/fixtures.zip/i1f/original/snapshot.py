def snapshot(pair,confidence=.95):
    approaches=[]
    for group,(q,arrival,service,capacity) in zip(("A","B"),pair):
        approaches.append(QueueApproachState(approach_id=group,service_group=group,
            visible_vehicles=q,queue_length=q,stopped_ratio=float(q>0),
            arrival_rate_vps=arrival,discharge_rate_vps=service,
            queue_growth_vps=arrival-service,mean_wait_seconds=0.,max_wait_seconds=0.,
            storage_capacity_vehicles=capacity,storage_occupancy_ratio=q/capacity,
            spillback_margin_ratio=max(0.,1-q/capacity),observation_confidence=confidence,
            visibility_calibrated=False,quality="experimental"))
    uid=UUID(int=1)
    return QueueSnapshot(source_id="SI11_SYNTHETIC",intersection_code="SI11_SYNTHETIC",
        session_id=uid,tracking_epoch=uid,analytics_epoch=uid,queue_epoch=uid,
        geometry_sha256="a"*64,model_sha256="b"*64,purpose="validation_only",
        data_origin="synthetic_demo",commercial_demo_authorized=False,frame_sequence=1,
        received_at=datetime(2020,1,1,tzinfo=timezone.utc),approaches=tuple(approaches))
