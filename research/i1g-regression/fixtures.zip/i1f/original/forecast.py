def observed(pair,queues,t,confidence=.95):
    base=snapshot(pair,confidence).model_dump()
    for g,(q,row) in enumerate(zip(queues,base["approaches"])):
        n=len(q)
        if n>200:
            raise ValueError("synthetic queue outside snapshot contract")
        ages=[t-b for b in q]
        row.update(queue_length=n,visible_vehicles=n,stopped_ratio=float(n>0),
            mean_wait_seconds=fmean(ages) if ages else 0.,
            max_wait_seconds=max(ages,default=0),
            storage_occupancy_ratio=min(2.,n/pair[g][3]),
            spillback_margin_ratio=max(0.,1-n/pair[g][3]))
    return QueueSnapshot.model_validate(base)


def current_pair(pair,queues):
    return tuple((len(q),*p[1:]) for p,q in zip(pair,queues))


def forecast(q,pair,action,stress):
    """Independent fluid forecast; actual evaluation uses integer FIFO."""
    a=[min(1.,p[1]+stress) for p in pair]
    s=[max(0.,p[2]-stress) for p in pair]
    caps=[p[3] for p in pair]
    q=list(q); area=critical=overflow=imbalance=0.
    for active in schedule(action):
        for g in (0,1):
            q[g]=max(0.,q[g]+a[g]-(s[g] if active==g else 0.))
        area+=sum(q)
        critical+=sum(max(0.,q[g]-.85*caps[g]) for g in (0,1))
        overflow+=sum(max(0.,q[g]-caps[g]) for g in (0,1))
        imbalance+=abs(q[0]/caps[0]-q[1]/caps[1])
    return tuple(q),area+4*critical+15*overflow+imbalance
