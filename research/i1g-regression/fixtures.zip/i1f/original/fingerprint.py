def fingerprint(payload: dict) -> str:
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",",":"), allow_nan=False).encode("utf-8")
    return sha256(encoded).hexdigest()
