def schedule(action):
    first,w=action
    if first not in (0,1) or type(w) is not int or not 12<=w<=40:
        raise ValueError("invalid synthetic action")
    return (first,)*w+(None,)*TRANSITION+(1-first,)*(SERVICE-w)+(None,)*TRANSITION
