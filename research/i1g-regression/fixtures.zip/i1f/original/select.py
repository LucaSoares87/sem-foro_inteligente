def select(policy,pair,queues,t,confidence=.95):
    state=observed(pair,queues,t,confidence)
    original=evaluate(state)
    if (original.origin!="synthetic_demo" or original.operational_decision!="abstain"
            or original.physical_actuation or original.operationally_validated):
        raise AssertionError("operational boundary violated")
    if original.preferred_in_simulation=="abstain":
        return None, "low_confidence_abstain"
    major=int(original.major_group.group_id=="B")
    minor=1-major
    p=current_pair(pair,queues)
    fixed=(t//CYCLE%2,26)
    if policy=="fixed_alternating":
        return fixed,"fixed"
    if policy=="demand_proportional":
        demand=[(x[0]+CYCLE*x[1])/max(.05,x[2]) for x in p]
        first=major
        w=SERVICE*demand[first]/max(1e-9,sum(demand))
        return (first,max(12,min(40,round(w)))),"proportional"
    if policy in ("predictive_x","predictive_no_x"):
        action=predictive(p,major,policy=="predictive_x")
        return action,"predictive" if action else "no_common_forecast_action"
    if policy not in ("original_x","robust_x"):
        raise ValueError("unknown policy")
    w=math.ceil(original.minor_first.analysis_first_window_seconds) if original.minor_first else 28
    pref=original.preferred_in_simulation
    if policy=="robust_x":
        candidate=robust_choose(p,original)
        pref=candidate["preference"]
        if candidate["window"] is not None:
            w=candidate["window"]
    if pref not in ("minor_first","major_first"):
        return fixed,"no_material_advantage_fixed"
    return (minor if pref=="minor_first" else major,max(12,min(40,w))),pref
