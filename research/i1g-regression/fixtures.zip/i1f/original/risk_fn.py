def step(dist, probabilities):
    out={}
    for state,mass in dist.items():
        for increment,prob in probabilities:
            if prob:
                out[state+increment]=out.get(state+increment,0.)+mass*prob
    return out


def risk_profile(minor,major):
    """Exact discrete iid stress distributions; no realized future arrivals used.

    X(window) is a lower quantile of cumulative net service opportunities.
    Net >= initial queue is sufficient for clearing at least once by window end,
    not for remaining empty. Major arrivals are nonnegative before its service.
    """
    q,ar,sr,cap=minor
    mq,ma,_,mc=major
    ar=min(1.,ar+RATE_MARGIN)
    sr=max(0.,sr-RATE_MARGIN)
    ma=min(1.,ma+RATE_MARGIN)
    headroom=math.floor(STORAGE_RATIO*mc)-mq
    arrivals={0:1.}
    net={0:1.}
    risks={}
    for t in range(1,MAX_WINDOW+TRANSITION+1):
        arrivals=step(arrivals,((0,1-ma),(1,ma)))
        risks[t]=sum(m for k,m in arrivals.items() if k>headroom)
    profile=[]
    for t in range(1,MAX_WINDOW+1):
        net=step(net,((-1,ar*(1-sr)),(0,ar*sr+(1-ar)*(1-sr)),(1,(1-ar)*sr)))
        major_risk=risks[t+TRANSITION]
        feasible_counts=[k for k in range(0,min(t,math.floor(STORAGE_RATIO*cap))+1)
                         if sum(m for n,m in net.items() if n>=k)>=1-RISK-1e-12]
        x=max(feasible_counts,default=0)
        clear_prob=sum(m for n,m in net.items() if n>=q)
        eligible=major_risk<=RISK+1e-12 and clear_prob>=1-RISK-1e-12 and q<=x
        profile.append({"window":t,"x":x if major_risk<=RISK+1e-12 else 0,
                        "major_critical_probability_assumed":major_risk,
                        "minor_clearance_lower_probability_assumed":clear_prob,"eligible":eligible})
    return profile
