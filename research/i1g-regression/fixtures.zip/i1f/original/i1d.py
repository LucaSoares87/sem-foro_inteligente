CANDIDATE="order_x"
POLICIES=(*d.POLICIES,CANDIDATE)


def forecast_cost(pair, action, ages, stress):
    first,w=action
    _,cost=c.forecast(tuple(p[0] for p in pair),pair,action,stress)
    return cost+2*max(ages[first],ages[1-first]+w+c.TRANSITION)


def select(policy,pair,queues,t,confidence=.95):
    if policy!=CANDIDATE:
        return c.select(policy,pair,queues,t,confidence)
    base,reason=c.select("demand_proportional",pair,queues,t,confidence)
    if base is None:
        return base,reason
    major,w=base
    minor=1-major
    p=c.current_pair(pair,queues)
    if not 0<p[minor][0]<p[major][0]:
        return base,"order_keep_empty_or_tie"
    result=evaluate(c.observed(pair,queues,t,confidence))
    assert result.origin=="synthetic_demo" and result.operational_decision=="abstain"
    assert not result.physical_actuation and not result.operationally_validated
    if (result.preferred_in_simulation=="abstain" or not result.minor_clearance_feasible
            or p[minor][0]>result.dynamic_x_safe_vehicles):
        return base,"order_keep_x_veto"
    alt=(minor,c.SERVICE-w)
    if not any(r["window"]==alt[1] and r["eligible"] for r in risk_profile(p[minor],p[major])):
        return base,"order_keep_risk_veto"
    ages=[max((t-b for b in q),default=0) for q in queues]
    if ages[major]+alt[1]+c.TRANSITION>180:
        return base,"order_keep_wait_veto"
    for stress in (0.,.05):
        original=forecast_cost(p,base,ages,stress)
        alternate=forecast_cost(p,alt,ages,stress)
        if original<=0 or alternate>.95*original:
            return base,"order_keep_cost_veto"
    assert alt[1]+base[1]==c.SERVICE
    return alt,"order_minor_first"
