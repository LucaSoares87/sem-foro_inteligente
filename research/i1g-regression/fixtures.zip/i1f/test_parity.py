import json, math, hashlib
from pathlib import Path
import pytest
import parity as p
from parity import diag
ROOT=Path(__file__).resolve().parent

@pytest.fixture(scope='module')
def report():
    return json.loads((ROOT/'parity-report.json').read_text())

def test_report_digest(report):
    d=dict(report);h=d.pop('report_sha256');assert p.F.fingerprint(d)==h

def test_grid_preserved(report):
    assert report['frozen']==384 and report['comparisons']==812
    assert not report['mismatches'] and report['parity_passed']
    assert report['grid_original_reasons']=={'order_keep_cost_veto':180,'order_keep_risk_veto':164,'order_keep_wait_veto':22,'order_minor_first':18}

def test_swap(report):
    rows=[r for r in report['rows'] if r['kind']=='frozen_grid']
    for a,b in zip(rows[::2],rows[1::2]):
        assert a['case']==b['case'] and not a['swap'] and b['swap']
        assert a['actual'][1]==b['actual'][1]
        assert a['actual'][0][0]==1-b['actual'][0][0] and a['actual'][0][1]==b['actual'][0][1]
        assert a['green_budget_by_label'][:2]==b['green_budget_by_label'][:2][::-1]
        assert a['diagnostic']['prospective_joint']==b['diagnostic']['prospective_joint']

def test_safety(report):
    for r in report['rows']:
        assert r['operational_decision']=='abstain' and r['physical_actuation'] is False and r['candidate_promoted'] is False
        assert r['actual']==r['expected'] and r['green_budget_by_label']==r['alternate_green_budget_by_label']

def test_stage_order(report):
    for r in report['rows']:
        active=True
        for k in ['confidence','positive_unequal','x_feasible','risk','major_wait','cost_nominal','cost_stress']:
            assert r['evaluated_stages'][k] is active
            active=active and r['diagnostic']['checks'][k]

def test_profiles_all_windows(report):
    # For all distinct group rate/queue/capacity pairs, compare the 30 original windows.
    pairs={ (tuple(r['diagnostic']['minor'][k] for k in ('q','a','s','cap')),tuple(r['diagnostic']['major'][k] for k in ('q','a','s','cap'))) for r in report['rows'] }
    maxima=[0.,0.];n=0
    for m,M in sorted(pairs):
        orig=p.profile(m,M)
        assert len(orig)==30
        for o in orig:
            v=diag.risks(m,M,o['window']);n+=1
            assert v['eligible']==o['eligible'] and v['risk_x']==o['x']
            for i,(a,b) in enumerate(((v['major_risk'],o['major_critical_probability_assumed']),(v['minor_clearance'],o['minor_clearance_lower_probability_assumed']))):
                maxima[i]=max(maxima[i],abs(a-b));assert abs(a-b)<=1e-12
    (ROOT/'risk-all-windows.json').write_text(json.dumps({'pairs':len(pairs),'windows':n,'max_abs_errors':maxima},sort_keys=True,indent=2)+'\n')

@pytest.mark.parametrize('name,field,expected',[
 ('zero_net','x_feasible',False),('negative_net','x_feasible',False),('major_at_critical','x_feasible',False),('minor_storage_cap','x_feasible',False),('clear_30','x_feasible',True),('clear_32','x_feasible',False),('window_30','risk_window',True),('window_31','risk_window',False),('low_confidence','confidence',False),('confidence_exact','confidence',True),('wait_180','major_wait',True),('wait_181','major_wait',False),('minor_empty','positive_unequal',False),('both_empty','positive_unequal',False),('tie_exact','positive_unequal',False)])
def test_boundary(report,name,field,expected):
    rows=[r for r in report['rows'] if r['kind']=='boundary' and r['case']==name]
    assert len(rows)==2
    assert all(r['diagnostic']['checks'][field] is expected for r in rows)

@pytest.mark.parametrize('name,expected',[('receiving_unknown',None),('receiving_short',False),('receiving_exact',True)])
def test_receiving(report,name,expected):
    rows=[r for r in report['rows'] if r['kind']=='boundary' and r['case']==name]
    assert len(rows)==2 and all(r['diagnostic']['receiving_envelope'] is expected for r in rows)

def test_invalid_domain():
    with pytest.raises(ValueError):diag.Group(1,float('nan'),.5,20)
    with pytest.raises(ValueError):diag.Group(1,.1,1.01,20)
    with pytest.raises(ValueError):p.run_state(diag.Group(1,0,.9,20),diag.Group(4,0,.5,20),receiving=(-1,20))

def test_frozen_source():
    assert p.load()

def test_risk_bounds(report):
    for r in report['rows']:
        if r['original_risk']:
            assert r['risk_margins']['quantile']==r['original_risk']['x']-r['diagnostic']['minor']['q']
