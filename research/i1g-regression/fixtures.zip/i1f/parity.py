"""Offline excerpt parity. No runtime imports, simulator, physical connection or promotion."""
from pathlib import Path
import sys, json, math, hashlib, types, time
from datetime import datetime, timezone
from uuid import UUID
from typing import Literal
from statistics import fmean
from functools import lru_cache
from collections import Counter
from pydantic import AwareDatetime, BaseModel, ConfigDict, Field
from hashlib import sha256
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'prior'))
import diagnostic as diag

def fnv(s):
    v=2166136261
    for c in s:v=((v^ord(c))*16777619)&0xffffffff
    return f'{v:08x}'

def load():
    meta=json.loads((ROOT/'provenance.json').read_text())['excerpts']
    chunks={}
    sha_manifest=json.loads((ROOT/'excerpt-sha256.json').read_text())
    for name,(_,n,h) in meta.items():
        s=(ROOT/'original'/f'{name}.py').read_text()
        if (len(s),fnv(s))!=(n,h):raise ValueError('source excerpt mismatch: '+name)
        if hashlib.sha256(s.encode()).hexdigest()!=sha_manifest[name]:raise ValueError('source SHA256 mismatch: '+name)
        chunks[name]=s
    common=dict(Literal=Literal,UUID=UUID,AwareDatetime=AwareDatetime,BaseModel=BaseModel,ConfigDict=ConfigDict,Field=Field,datetime=datetime,timezone=timezone,json=json,sha256=sha256,math=math,floor=math.floor,fmean=fmean)
    def module(name,parts,extra=None):
        m=types.ModuleType('i1f_'+name);sys.modules[m.__name__]=m;m.__dict__.update(common);m.__dict__.update(extra or {})
        for key in parts:exec(compile(chunks[key],str(ROOT/'original'/f'{key}.py'),'exec'),m.__dict__)
        return m
    core=module('contract',['contract','fingerprint']);models=module('models',['queue_contracts','opt_contracts'],{'Contract':core.Contract})
    extras={k:getattr(models,k) for k in ('QueueApproachState','QueueSnapshot','ServiceGroupState','CandidateMetrics','OptimizationResult')}
    e=module('engine',['engine'],dict(extras,fingerprint=core.fingerprint));risk=module('risk',['risk','risk_fn'])
    c=module('c',['snapshot','c','schedule','forecast','select'],dict(extras,evaluate=e.evaluate))
    d=types.SimpleNamespace(POLICIES=('fixed_alternating','demand_proportional','predictive_x','predictive_no_x'))
    i=module('i1d',['i1d'],dict(c=c,d=d,evaluate=e.evaluate,risk_profile=risk.risk_profile))
    return e,risk,c,i,core

E,R,C,I,F=load()
@lru_cache(maxsize=512)
def profile(m,M):return R.risk_profile(m,M)

def groups_from_snapshot(s,engine=E):
    g=engine.aggregate_groups(s);major,minor=engine._major_minor(g)
    def convert(x):return diag.Group(x.queue_length,x.arrival_rate_vps,x.discharge_rate_vps,x.storage_capacity_vehicles,int(x.max_wait_seconds))
    return major,minor,convert(minor),convert(major)

def same_num(a,b):
    return (a is None and b is None) or (a is not None and b is not None and math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12))

def instrument(pair,queues,t,confidence=.95,receiving=None,*,modules=None):
    E,R,C,I=modules if modules is not None else (globals()["E"],globals()["R"],globals()["C"],globals()["I"])
    # Research-only adapter: return the original decision, never a decision from diagnostics.
    snap=C.observed(pair,queues,t,confidence);actual=I.select('order_x',pair,queues,t,confidence)
    base=C.select('demand_proportional',pair,queues,t,confidence);result=E.evaluate(snap)
    major,minor,m,M=groups_from_snapshot(snap,E);mi=int(minor.group_id=='B');ma=1-mi
    ordered_receiving=None if receiving is None else (receiving[mi],receiving[ma])
    row=diag.diagnose(m,M,confidence,ordered_receiving);w,wm=row['green_by_group']
    # Counterfactual base is only for trace when original abstains; action stays None.
    alt=(mi,w);base_model=(ma,wm)
    expected=(None,row['reason']) if not row['checks']['confidence'] else ((alt if row['reason']=='order_minor_first' else base_model),row['reason'])
    mismatches=[]
    def check(name,ok):
        if not ok:mismatches.append(name)
    check('reason_action',actual==expected)
    check('base',base==(None,'low_confidence_abstain') if not row['checks']['confidence'] else base==(base_model,'proportional'))
    x,clear=E.dynamic_x_safe(minor,major)
    check('x',x==row['x']['x']);check('clear',same_num(clear,row['x']['clear']))
    if row['checks']['confidence'] and row['checks']['positive_unequal']:
        check('engine_x_feasible',result.minor_clearance_feasible==row['checks']['x_feasible'])
    original_risk=None if w>30 else (profile(m.p(),M.p()) if modules is None else R.risk_profile(m.p(),M.p()))[w-1]
    rp=row['risk']
    if original_risk is None:check('risk_window',rp is None)
    else:
        check('risk_eligible',original_risk['eligible']==rp['eligible']);check('risk_quantile',original_risk['x']==rp['risk_x'])
        check('major_prob',same_num(original_risk['major_critical_probability_assumed'],rp['major_risk']))
        check('minor_prob',same_num(original_risk['minor_clearance_lower_probability_assumed'],rp['minor_clearance']))
    ages=[max((t-b for b in q),default=0) for q in queues]
    current=C.current_pair(pair,queues)
    costs=[]
    for c in row['costs']:
        a=I.forecast_cost(current,base_model,ages,c['stress']);b=I.forecast_cost(current,alt,ages,c['stress']);passed=a>0 and b<=.95*a
        check('cost_values',same_num(a,c['base']) and same_num(b,c['alt']));check('cost_gate',passed==c['passed']);costs.append({'stress':c['stress'],'base':a,'alternate':b,'passed':passed,'margin':.95*a-b})
    check('wait_gate',(ages[ma]+w+4<=180)==row['checks']['major_wait'])
    s0,s1=C.schedule(base_model),C.schedule(alt)
    counts=lambda s:[s.count(0),s.count(1),s.count(None)]
    check('green_budget',counts(s0)==counts(s1) and sum(counts(s0))==60 and counts(s0)[2]==8)
    check('safety',result.operational_decision=='abstain' and not result.physical_actuation and not result.operationally_validated and result.origin=='synthetic_demo')
    # Preserve ordered labels and actual evaluation order; all computed later checks diagnostic only.
    stages=['confidence','positive_unequal','x_feasible','risk','major_wait','cost_nominal','cost_stress'];evaluated={};active=True
    for k in stages:
        evaluated[k]=active
        active=active and row['checks'][k]
    trace={'snapshot_sha256':result.state_sha256,'engine_result_sha256':result.result_sha256,'groups':[g.model_dump(mode='json') for g in E.aggregate_groups(snap)],'major_label':major.group_id,'minor_label':minor.group_id,'base':base,'actual':actual,'expected':expected,'green_budget_by_label':counts(s0),'alternate_green_budget_by_label':counts(s1),'raw_x':x,'raw_clear':clear,'engine_reason':result.reason,'engine_x_feasible':result.minor_clearance_feasible,'original_risk':original_risk,'risk_margins':None if original_risk is None else {'major':.05-original_risk['major_critical_probability_assumed'],'minor':original_risk['minor_clearance_lower_probability_assumed']-.95,'quantile':original_risk['x']-m.q},'costs':costs,'evaluated_stages':evaluated,'diagnostic':row,'mismatches':mismatches,'physical_actuation':False,'candidate_promoted':False,'operational_decision':'abstain'}
    return actual,trace

def run_state(m,M,conf=.95,receiving=None,swap=False):
    g=[m,M];rec=receiving
    if swap:g.reverse();rec=None if receiving is None else receiving[::-1]
    t=max(240,*(x.age for x in g));qs=[[t-x.age]*x.q for x in g]
    return instrument(tuple(x.p() for x in g),qs,t,conf,rec)[1]

def main():
    previous=json.loads((ROOT/'prior/report.json').read_text());digest=previous.pop('report_sha256');assert F.fingerprint(previous)==digest
    states=previous['rows'];out=[];start=time.perf_counter()
    for index,r in enumerate(states):
        m,M=diag.Group(**r['minor']),diag.Group(**r['major']);conf=r['confidence'];receiving=tuple(r['receiving_space'])
        for swap in (False,True):
            tr=run_state(m,M,conf,receiving,swap);tr.update(case=index,swap=swap,kind='frozen_grid')
            if tr['diagnostic']['reason']!=r['reason'] or tr['diagnostic']['green_by_group']!=r['green_by_group'] or tr['diagnostic']['prospective_joint']!=r['prospective_joint']:tr['mismatches'].append('frozen_report')
            out.append(tr)
    bounds=json.loads((ROOT/'boundaries.json').read_text())
    for index,b in enumerate(bounds):
        for swap in (False,True):
            tr=run_state(diag.Group(*b['m']),diag.Group(*b['M']),b.get('confidence',.95),b.get('receiving'),swap);tr.update(case=b['id'],swap=swap,kind='boundary')
            if b.get('expected') and tr['actual'][1]!=b['expected']:tr['mismatches'].append('boundary_oracle')
            out.append(tr)
    failures=[{'kind':r['kind'],'case':r['case'],'swap':r['swap'],'mismatches':r['mismatches']} for r in out if r['mismatches']]
    report={'scope':'original_excerpts_offline_parity_not_integrated_runtime','prior_report_sha256':digest,'rows':out,'frozen':len(states),'boundary':len(bounds),'comparisons':len(out),'mismatches':failures,'grid_original_reasons':dict(Counter(r['actual'][1] for r in out if r['kind']=='frozen_grid' and not r['swap'])),'parity_passed':not failures,'physical_actuation':False,'candidate_promoted':False,'operational_decision':'abstain'}
    report['report_sha256']=F.fingerprint(report)
    (ROOT/'parity-report.json').write_text(json.dumps(report,sort_keys=True,indent=2,allow_nan=False)+'\n');print({k:v for k,v in report.items() if k!='rows'});print('Elapsed seconds',time.perf_counter()-start)
if __name__=='__main__':main()
