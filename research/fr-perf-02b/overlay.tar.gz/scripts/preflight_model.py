"""Offline smoke only: no Bellevue, no campaign, no controller, no network."""
import argparse, json, sys, platform, hashlib
from pathlib import Path

def main():
    p=argparse.ArgumentParser();p.add_argument('--model-spec',required=True,type=Path);p.add_argument('--model-root',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
    if sys.version_info[:2]!=(3,12) or platform.system()!='Linux' or platform.machine()!='x86_64':p.error('requires CPython 3.12 Linux x86_64')
    import cv2,numpy as np,onnxruntime as ort
    from src.vision.contracts import ModelSpec
    from src.benchmarking.fr_perf_02b import Detector,matched_differences,digest,save,MODEL
    from src.benchmarking.si10_cpu_profile import cpu_budget
    if cv2.__version__!='4.11.0' or np.__version__!='2.2.6' or ort.__version__!='1.22.0':p.error('pinned environment mismatch')
    spec=ModelSpec.model_validate_json(a.model_spec.read_text());path=spec.resolve(a.model_root)
    if digest(path.read_bytes())!=MODEL:p.error('model mismatch')
    # Synthetic patterns exercise shape/dtype/output validity only. Empty detections do not count as real parity.
    imgs=[]
    for i in range(4):
        img=np.zeros((240,320,3),np.uint8);cv2.rectangle(img,(20+5*i,100),(65+5*i,128),(30,80,220),-1);imgs.append(img)
    results=[];budget=cpu_budget()
    for threads in (2,4):
        if threads>budget['thread_budget']:continue
        a0=Detector(path,spec,'ocv',threads);ref=[a0.infer(img,False)[0] for img in imgs]
        del a0
        b0=Detector(path,spec,'ort',threads);cand=[b0.infer(img,False)[0] for img in imgs]
        del b0
        for i,(x,y) in enumerate(zip(ref,cand)):
            results.append(dict(threads=threads,slot=i,reference_count=len(x),candidate_count=len(y),**matched_differences(x,y)))
    if not results:raise ValueError('insufficient CPU budget')
    save(a.output,dict(scope='synthetic_preflight_not_screening',model_sha256=MODEL,hardware=budget,results=results,all_match=all(x['match'] for x in results),nonempty_reference=any(x['reference_count'] for x in results),screening_released=False,physical_actuation=False,candidate_promoted=False,human_acceptance='PENDING_HUMAN'))
if __name__=='__main__':main()
