"""Generate an exact platform-specific wheel lock from pip's resolver report.
Does not contact network itself. Generate the report only on authorized CP312 Linux x86_64.
"""
import argparse,json,re
from pathlib import Path
from urllib.parse import urlparse,unquote
ORT_HASH='6964a975731afc19dc3418fad8d4e08c48920144ff590149429a5ebe0d15fb3c'
def lock(report):
    env=report['environment']
    if env['python_version']!='3.12' or env['platform_system']!='Linux' or env['platform_machine']!='x86_64' or env.get('implementation_name')!='cpython':raise ValueError('wrong target')
    result={}
    for item in report['install']:
        metadata=item['metadata'];name=re.sub(r'[-_.]+','-',metadata['name']).lower();ver=metadata['version']
        download=item['download_info'];url=urlparse(download['url']);sha=download['archive_info']['hashes']['sha256']
        if not re.fullmatch(r'[a-f0-9]{64}',sha) or url.scheme!='https' or url.hostname!='files.pythonhosted.org' or not unquote(url.path).endswith('.whl') or not re.fullmatch(r'[a-z0-9-]+',name) or not re.fullmatch(r'[A-Za-z0-9.!+_-]+',ver):raise ValueError('invalid wheel provenance')
        if name in result:raise ValueError('duplicate dependency')
        result[name]=(ver,sha)
    if result.get('onnxruntime')!=('1.22.0',ORT_HASH):raise ValueError('ORT wheel differs from preregistration')
    # The report must include the complete original dev environment plus ORT, not a report from an already-installed host.
    required={'fastapi':'0.115.12','uvicorn':'0.34.2','websockets':'15.0.1','sqlalchemy':'2.0.41','psycopg':'3.2.9','psycopg-binary':'3.2.9','alembic':'1.16.1','pydantic-settings':'2.9.1','numpy':'2.2.6','opencv-python-headless':'4.11.0.86','scipy':'1.15.3','pytest':'8.4.0','httpx':'0.28.1','pytest-cov':'6.1.1','onnx':'1.17.0'}
    if any(result.get(n,(None,None))[0]!=v for n,v in required.items()):raise ValueError('missing or changed original dependency')
    return '\n'.join(f'{name}=={ver} --hash=sha256:{sha}' for name,(ver,sha) in sorted(result.items()))+'\n'
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('report',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    with a.output.open('x') as f:f.write(lock(json.loads(a.report.read_text())))
