import pytest
from lock_from_report import lock,ORT_HASH

def test_wrong_target():
    with pytest.raises(ValueError):lock({'environment':{'python_version':'3.13','platform_system':'Linux','platform_machine':'x86_64','implementation_name':'cpython'},'install':[]})
def test_missing_ort():
    with pytest.raises(ValueError):lock({'environment':{'python_version':'3.12','platform_system':'Linux','platform_machine':'x86_64','implementation_name':'cpython'},'install':[]})
def test_wrong_wheel_hash():
    with pytest.raises(ValueError):lock({'environment':{'python_version':'3.12','platform_system':'Linux','platform_machine':'x86_64','implementation_name':'cpython'},'install':[{'metadata':{'name':'onnxruntime','version':'1.22.0'},'download_info':{'url':'https://files.pythonhosted.org/test.whl','archive_info':{'hashes':{'sha256':'0'*64}}}}]})
def test_missing_closure():
    with pytest.raises(ValueError):lock({'environment':{'python_version':'3.12','platform_system':'Linux','platform_machine':'x86_64','implementation_name':'cpython'},'install':[{'metadata':{'name':'onnxruntime','version':'1.22.0'},'download_info':{'url':'https://files.pythonhosted.org/test.whl','archive_info':{'hashes':{'sha256':ORT_HASH}}}}]})
