"""Research-only screening implementation; dispatch remains blocked pending real preflight."""
import argparse, asyncio, hashlib, json, math, os, sys, resource, time, platform
from pathlib import Path
from statistics import median
from datetime import datetime, timezone, timedelta
from uuid import UUID
from types import SimpleNamespace

SCREENING_RELEASED=False # reviewed release only after external preflight; never set by CLI
MODEL='c5c2d13e59ae883e6af3b45daea64af4833a4951c92d116ec270d9ddbe998063'
SLOTS=tuple(range(0,500,16))

def order(budget):
    if type(budget) is not int or budget<2: raise ValueError('insufficient CPU budget')
    a=[(b,n) for n in (2,4) if n<=budget for b in ('ocv','ort')]
    return a+list(reversed(a))

def p95(x):
    if not x or any(not math.isfinite(v) or v<0 for v in x): raise ValueError('invalid timing')
    return sorted(x)[math.ceil(.95*len(x))-1]

def finite_nonnegative(x):
    return type(x) in (int,float) and math.isfinite(x) and x>=0

def eligible(base,candidate):
    if len(base)!=2 or len(candidate)!=2: return False
    if not all(x.get('parity') is True and x.get('functional_parity') is True and x.get('overhead_validated') is True and all(finite_nonnegative(x.get(k)) for k in ('synthetic_p95','cpu_per_frame')) for x in base+candidate): return False
    b=median([x['synthetic_p95'] for x in base]); c=median([x['synthetic_p95'] for x in candidate])
    return b>0 and c<=180 and (b-c)/b>=.2 and median([x['cpu_per_frame'] for x in candidate])<=median([x['cpu_per_frame'] for x in base])

def select(blocks,budget):
    if [(x['backend'],x['threads']) for x in blocks]!=order(budget): raise ValueError('incomplete or reordered blocks')
    ranked=[]
    for n in (2,4):
        if n>budget: continue
        base=[x for x in blocks if x['backend']=='ocv' and x['threads']==n]
        cand=[x for x in blocks if x['backend']=='ort' and x['threads']==n]
        if eligible(base,cand): ranked.append((median(x['cpu_per_frame'] for x in cand),median(x['synthetic_p95'] for x in cand),n))
    return min(ranked)[2] if ranked else None

def distribution(values):
    return dict(count=len(values),p50=median(values),p95=p95(values),max=max(values))

def paired_overhead(plain,profiled):
    if len(plain)!=len(profiled) or not plain or not all(finite_nonnegative(x) and x>0 for x in plain+profiled): raise ValueError('invalid overhead samples')
    value=median([(b-a)/a for a,b in zip(plain,profiled)])
    return dict(median_relative=value,pass_gate=value<=.05)

def reconcile(roundtrip,child_elapsed,stages):
    if not all(finite_nonnegative(x) for x in [roundtrip,child_elapsed,*stages.values()]): raise ValueError('invalid durations')
    internal=child_elapsed-sum(stages.values()); transport=roundtrip-child_elapsed
    if internal<-.01 or transport<-.01: raise ValueError('nonconserving timing')
    return dict(child_residual_ms=internal,transport_residual_ms=transport)

def matched_differences(reference,candidate,tol=1e-4):
    import numpy as np
    from scipy.optimize import linear_sum_assignment
    if len(reference)!=len(candidate): return dict(match=False,box_max=None,score_max=None)
    if not reference: return dict(match=True,box_max=0.,score_max=0.)
    costs=np.full((len(reference),len(candidate)),1e9); errors={}
    for i,a in enumerate(reference):
        for j,b in enumerate(candidate):
            box=max(abs(x-y) for x,y in zip(a.xyxy,b.xyxy)); score=abs(a.confidence-b.confidence)
            if a.label==b.label and box<=tol and score<=tol:
                costs[i,j]=box+score;errors[i,j]=(box,score)
    ri,ci=linear_sum_assignment(costs)
    if any(costs[i,j]>=1e9 for i,j in zip(ri,ci)):return dict(match=False,box_max=None,score_max=None)
    pairs=[errors[i,j] for i,j in zip(ri,ci)]
    return dict(match=True,box_max=max(x[0] for x in pairs),score_max=max(x[1] for x in pairs))

def normalize(value):
    # Only known UUID epochs and measurement durations are nonfunctional.
    if isinstance(value,dict):return {k:normalize(v) for k,v in value.items() if k not in ('tracking_epoch','analytics_epoch','tracking_ms','inference_ms')}
    if isinstance(value,(tuple,list)):return [normalize(x) for x in value]
    return value

def functional_trace(outputs,spec,timing=None):
    from src.vision.contracts import DetectionBatch
    from src.tracking.service import TrackingService
    from src.analytics.service import AnalyticsService
    from src.analytics.contracts import SourceGeometry
    key='FR_PERF_LAB'; session=UUID(int=1); now=datetime(2020,1,1,tzinfo=timezone.utc)
    if len(outputs)!=96:raise ValueError('functional input count')
    result=[]
    class TimedAnalytics(AnalyticsService):
        def consume(self,batch):
            t=time.monotonic_ns();super().consume(batch);self.last_ms=(time.monotonic_ns()-t)/1e6
    # Separate clips; fixed 200 ms fixture timestamps, not real video cadence.
    for part in range(3):
        video=SimpleNamespace(sessions={key:SimpleNamespace(session_id=session,state='ended')})
        vision=SimpleNamespace(video=video,spec=spec,state='ready',results={})
        vision.valid_result=vision.results.get
        tracking=TrackingService(vision);vision.tracking=tracking
        geom=SourceGeometry.model_validate(dict(source_id=key,intersection_code=key,regions=[dict(region_id='lab',xyxy=[.1,.1,.9,.9])],lines=[dict(line_id='lab_line',start=[.1,.5],end=[.9,.5])]))
        analytics=TimedAnalytics(tracking,{key:geom});tracking.analytics=analytics
        for i,ds in enumerate(outputs[part*32:(part+1)*32],1):
            stamp=now+timedelta(milliseconds=200*i)
            b=DetectionBatch(source_id=key,intersection_code=key,session_id=session,frame_sequence=i,received_at=stamp,inferred_at=stamp,model_sha256=spec.sha256,purpose=spec.purpose,inference_ms=0.,detections=ds)
            vision.results[key]=b;t=time.monotonic_ns();tracking.consume(b);end=time.monotonic_ns()
            track=tracking.latest(key);snap=analytics.latest(key)
            if tracking.failed or analytics.failed or track is None or snap is None:raise ValueError('functional replay failure')
            result.append(normalize({'tracking':track.model_dump(mode='json'),'analytics':snap.model_dump(mode='json')}))
            if timing is not None:timing.append({'tracking_service_ms':(end-t)/1e6-analytics.last_ms,'analytics_service_ms':analytics.last_ms,'tracker_internal_ms':track.tracking_ms})
    return result


def rss_sample():
    try:
        return next(int(row.split()[1]) for row in Path('/proc/self/status').read_text().splitlines() if row.startswith('VmRSS:'))
    except (OSError,StopIteration,ValueError,IndexError):return None

def runtime_info():
    from importlib.metadata import version,PackageNotFoundError
    versions={}
    for name in ('onnxruntime','opencv-python-headless','numpy','scipy','pydantic'):
        try:versions[name]=version(name)
        except PackageNotFoundError:versions[name]=None
    try:quota=Path('/sys/fs/cgroup/cpu.max').read_text().strip()
    except OSError:quota=None
    return dict(python=platform.python_version(),platform=platform.platform(),versions=versions,affinity=sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else None,cgroup_cpu_max=quota,thread_environment={k:os.environ.get(k) for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS')})

def digest(data): return hashlib.sha256(data).hexdigest()

def save(path,obj):
    raw=json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    with path.open('x') as f: json.dump(dict(obj,report_sha256=digest(raw)),f,indent=2,allow_nan=False)

class Detector:
    def __init__(self,path,spec,backend,threads):
        import cv2, numpy as np
        from src.vision.yolo import YoloDetector
        data=Path(path).read_bytes()
        if digest(data)!=MODEL or spec.sha256!=MODEL or spec.architecture!='yolox' or spec.purpose!='validation_only' or (spec.confidence,spec.nms_iou)!=(.25,.45): raise ValueError('model contract')
        self.spec=spec;self.backend=backend
        if backend=='ocv':
            self.net=YoloDetector(path,spec).net; cv2.setNumThreads(threads)
        elif backend=='ort':
            import onnxruntime as ort
            if ort.__version__!='1.22.0': raise ValueError('ORT version')
            cv2.setNumThreads(1)
            opt=ort.SessionOptions();opt.intra_op_num_threads=threads;opt.inter_op_num_threads=1
            opt.execution_mode=ort.ExecutionMode.ORT_SEQUENTIAL;opt.graph_optimization_level=ort.GraphOptimizationLevel.ORT_ENABLE_ALL
            self.net=ort.InferenceSession(data,sess_options=opt,providers=['CPUExecutionProvider'])
            inputs=self.net.get_inputs();outputs=self.net.get_outputs()
            if self.net.get_providers()!=['CPUExecutionProvider'] or len(inputs)!=1 or len(outputs)!=1 or inputs[0].type!='tensor(float)' or outputs[0].type!='tensor(float)': raise ValueError('ORT contract')
            self.input=inputs[0].name;self.output=outputs[0].name
            if list(inputs[0].shape)!=[1,3,640,640] or list(outputs[0].shape)!=[1,8400,85]: raise ValueError('ORT shape')
        else: raise ValueError('backend')
        if cv2.getNumThreads()!=(threads if backend=='ocv' else 1): raise ValueError('threads')
    def infer(self,image,profile=True):
        import numpy as np
        from src.vision.yolo import preprocess_yolox,decode_yolox
        t=time.monotonic_ns() if profile else 0;blob,geometry=preprocess_yolox(image);a=time.monotonic_ns() if profile else 0
        if blob.dtype!=np.float32 or blob.shape!=(1,3,640,640): raise ValueError('input contract')
        if self.backend=='ocv': self.net.setInput(blob);raw=self.net.forward()
        else: raw=self.net.run([self.output],{self.input:blob})[0]
        b=time.monotonic_ns() if profile else 0
        if raw.dtype!=np.float32 or raw.shape!=(1,8400,85): raise ValueError('output contract')
        det=decode_yolox(raw,geometry,self.spec.confidence,self.spec.nms_iou);c=time.monotonic_ns() if profile else 0
        return det,({'preprocess_ms':(a-t)/1e6,'forward_ms':(b-a)/1e6,'postprocess_ms':(c-b)/1e6} if profile else {})

def child(backend,threads,profile=True):
    import cv2,numpy as np
    from src.vision.contracts import ModelSpec
    from src.vision.worker import LENGTH,reply
    from src.video.contracts import MAX_JPEG,MAX_WIDTH,MAX_HEIGHT
    from src.benchmarking.si10_cpu_profile import cpu_budget
    if threads not in (2,4) or threads>cpu_budget()['thread_budget']: raise ValueError('budget')
    init=json.loads(sys.stdin.buffer.readline(8192));spec=ModelSpec.model_validate(init['spec']);d=Detector(spec.resolve(init['root']),spec,backend,threads)
    reply({'state':'ready','runtime':runtime_info(),'backend':backend,'threads':threads,'opencv_threads':cv2.getNumThreads()})
    while True:
        header=sys.stdin.buffer.read(LENGTH.size)
        if not header:return
        size=LENGTH.unpack(header)[0]
        if not 0<size<=MAX_JPEG:raise ValueError('size')
        data=sys.stdin.buffer.read(size)
        if len(data)!=size:raise ValueError('truncated')
        t=time.monotonic_ns();image=cv2.imdecode(np.frombuffer(data,np.uint8),cv2.IMREAD_COLOR);a=time.monotonic_ns()
        if image is None or not (0<image.shape[0]<=MAX_HEIGHT and 0<image.shape[1]<=MAX_WIDTH):raise ValueError('image')
        det,stage=d.infer(image,profile);b=time.monotonic_ns()
        values=[x.model_dump(mode='json') for x in det]
        # Serialize the actual payload once, append timing envelope; pipe write and envelope overhead remain residual.
        payload=json.dumps({'state':'ok','inference_ms':(b-t)/1e6,'detections':values},allow_nan=False,separators=(',',':')).encode()
        c=time.monotonic_ns()
        if profile: stage.update(jpeg_ms=(a-t)/1e6,serialization_ms=(c-b)/1e6)
        info={'stage':stage,'child_elapsed_ms':(c-t)/1e6,'cpu_seconds':time.process_time(),'rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'sampled_rss_kib':rss_sample()}
        sys.stdout.buffer.write(payload[:-1]+b','+json.dumps(info,allow_nan=False,separators=(',',':')).encode()[1:]+b'\n');sys.stdout.buffer.flush()

def worker_factory(spec,root,backend,threads,profile=True):
    from src.vision.service import InferenceWorker
    from src.video.manager import child_environment
    class Worker(InferenceWorker):
        async def open(self):
            self.process=await asyncio.create_subprocess_exec(sys.executable,'-m','src.benchmarking.fr_perf_02b','--worker',backend,str(threads),('profile' if profile else 'plain'),stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.DEVNULL,env=child_environment(),limit=65536)
            async with asyncio.timeout(30):
                self.process.stdin.write(json.dumps({'spec':self.spec.model_dump(mode='json'),'root':str(self.root)}).encode()+b'\n');await self.process.stdin.drain()
                self.ready_info=await self._reply()
                if self.ready_info.get('state')!='ready':raise ValueError('not ready')
    return Worker(spec,root)

async def measured_block(spec,root,backend,n,frames,profile):
    from src.vision.contracts import Detection
    w=worker_factory(spec,root,backend,n,profile);rows=[];outputs=[]
    try:
        await w.open()
        for f in frames[:3]:last=await w.infer(f)
        start_cpu=last['cpu_seconds'];parent_start=time.process_time()
        for j,f in enumerate(frames):
            offered=time.monotonic_ns();taken=time.monotonic_ns()
            v=await w.infer(f);received=time.monotonic_ns()
            ds=tuple(Detection.model_validate(x) for x in v['detections']);done=time.monotonic_ns()
            stages=v['stage'];rt=(received-taken)/1e6
            detail=reconcile(rt,v['child_elapsed_ms'],stages) if profile else None
            outputs.append(ds);rows.append({'slot':j,'offered_ns':offered,'taken_ns':taken,'received_ns':received,'validated_ns':done,'inference_ms':v['inference_ms'],'stage':stages,'ipc_roundtrip_ms':rt,'parent_validation_ms':(done-received)/1e6,'reconciliation':detail,'worker_lifetime_peak_rss_kib':v['rss_kib'],'parent_lifetime_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'worker_sampled_rss_kib':v['sampled_rss_kib'],'parent_sampled_rss_kib':rss_sample(),'detection_hash':digest(json.dumps(v['detections'],sort_keys=True).encode())})
        cpu=(v['cpu_seconds']-start_cpu)/len(frames);parent_cpu=(time.process_time()-parent_start)/len(frames)
        if not all(finite_nonnegative(x) for x in (cpu,parent_cpu)):raise ValueError('CPU clock')
        return rows,outputs,cpu,parent_cpu
    finally:await w.close()

async def screening(args):
    # The campaign API itself fails closed, not only the CLI. A later reviewed change
    # must remove this guard after pinned integration evidence exists.
    raise RuntimeError('SCREENING_BLOCKED_PENDING_REAL_PREFLIGHT')

async def _screening_design(args):
    if not SCREENING_RELEASED:raise RuntimeError('DESIGN_NOT_RELEASED')
    from src.benchmarking.fr_perf_01a import synthetic_frames,encode
    from src.benchmarking.si10_cpu_profile import HOLDOUTS,read_frames,cpu_budget
    from src.vision.contracts import ModelSpec
    from src.validation.io import load_json_model
    from src.validation.field_readiness import private_path
    spec=load_json_model(args.model_spec,ModelSpec);root=Path(args.model_root);out=private_path(args.output)
    if not out.is_dir():raise ValueError('private output directory required')
    hw=cpu_budget();schedule=order(hw['thread_budget']);synthetic=synthetic_frames()
    frames=[encode(x) for k in HOLDOUTS for x in read_frames(k,Path(args.holdouts)/HOLDOUTS[k][0])]+[synthetic[k] for k in SLOTS]
    if len(frames)!=96:raise ValueError('frame count')
    report={'hardware':hw,'parent_environment':runtime_info(),'model_sha256':MODEL,'schedule':schedule,'input_hashes':[digest(x) for x in frames],'blocks':[],'overhead':{},'complete':False,'physical_actuation':False,'candidate_promoted':False,'human_acceptance':'PENDING_HUMAN','phase_b':'DEFERRED','scope':'research_screening_not_capacity'}
    refs={};traces={};modes={}
    try:
        async with asyncio.timeout(480):
            # Fixed AB/BA fixture on 4 synthetic frames per feasible arm; separate from campaign.
            for backend,n in schedule[:len(schedule)//2]:
                samples=frames[64:68];plain=[];profiled=[];overhead_outputs=[]
                for mode in (False,True,True,False):
                    rows,ds,_,_=await measured_block(spec,root,backend,n,samples,mode)
                    (profiled if mode else plain).extend(x['ipc_roundtrip_ms'] for x in rows)
                    overhead_outputs.append(ds)
                o=paired_overhead(plain,profiled)
                o['parity']=all(all(matched_differences(a,b)['match'] for a,b in zip(overhead_outputs[0],ds)) for ds in overhead_outputs)
                o['plain_roundtrips_ms']=plain;o['profiled_roundtrips_ms']=profiled
                if not o['parity']:raise ValueError('overhead fixture parity')
                modes[backend,n]=o['pass_gate'];report['overhead'][f'{backend}{n}']=o
                save(out/f'overhead-{backend}{n}.json',o)
            for i,(backend,n) in enumerate(schedule):
                # If instrumentation exceeds its budget, measure unprofiled latency;
                # retain profile as separate diagnostic, never use it as capacity evidence.
                rows,outputs,cpu,parent_cpu=await measured_block(spec,root,backend,n,frames,modes[backend,n])
                functional_timings=[];trace=functional_trace(outputs,spec,functional_timings)
                if backend=='ocv' and n not in refs:refs[n]=outputs;traces[n]=trace
                ref=refs[n];differences=[matched_differences(a,b) for a,b in zip(ref,outputs)]
                functional=trace==traces[n]
                block={'backend':backend,'threads':n,'rows':rows,'parity':all(x['match'] for x in differences) and any(ref[:64]),'differences':differences,'functional_parity':functional,'functional_timings':functional_timings,'functional_hash':digest(json.dumps(trace,sort_keys=True).encode()),'overhead_validated':modes[backend,n],'synthetic_p95':p95([x['inference_ms'] for x in rows[64:]]),'bellevue_p95':p95([x['inference_ms'] for x in rows[:64]]),'cpu_per_frame':cpu,'parent_cpu_per_frame':parent_cpu,'synthetic_distribution':distribution([x['inference_ms'] for x in rows[64:]]),'bellevue_distribution':distribution([x['inference_ms'] for x in rows[:64]])}
                report['blocks'].append(block);save(out/f'block-{i+1:02}.json',block)
            report['selected_threads']=select(report['blocks'],hw['thread_budget']);report['complete']=True
            report['decision']='CANDIDATE_ELIGIBLE_FOR_REVIEW' if report['selected_threads'] else 'NO_ELIGIBLE_CANDIDATE'
    except Exception as exc:
        report['decision']='INCOMPLETE';report['error']=type(exc).__name__+':'+str(exc)[:200];raise
    finally:save(out/'screening.json',report)

def main():
    p=argparse.ArgumentParser();p.add_argument('--worker',nargs=3);p.add_argument('--authorize-screening',action='store_true')
    for k in ('model-spec','model-root','holdouts','output'):p.add_argument('--'+k)
    a=p.parse_args()
    if a.worker:
        if a.worker[2] not in ('profile','plain'):p.error('invalid worker mode')
        return child(a.worker[0],int(a.worker[1]),a.worker[2]=='profile')
    # Do not allow an incomplete protocol to consume experimental resources.
    p.error('FR-PERF-02B-CLOSE: screening disabled pending real pinned runtime/model, complete dependency lock and integrated preflight')
if __name__=='__main__':main()
