import asyncio, math
import pytest
from src.benchmarking.fr_perf_02b import (order,p95,eligible,SLOTS,select,paired_overhead,reconcile,matched_differences,functional_trace,Detector,MODEL,screening,_screening_design)

def test_order():
    assert order(4)==[('ocv',2),('ort',2),('ocv',4),('ort',4),('ort',4),('ocv',4),('ort',2),('ocv',2)]
    assert len(order(2))==4
    for b in (1,True,2.5):
        with pytest.raises(ValueError):order(b)
def test_slots():assert len(SLOTS)==32 and SLOTS[-1]==496
@pytest.mark.parametrize('v',[[],[float('nan')],[-1]])
def test_invalid(v):
    with pytest.raises(ValueError):p95(v)
def test_p95():assert p95(list(range(1,101)))==95

def block(b,n,p,c,**changes):
    return dict(backend=b,threads=n,synthetic_p95=p,cpu_per_frame=c,parity=True,functional_parity=True,overhead_validated=True)|changes

def test_gate():
    b=[block('ocv',2,230,.4)]*2;c=[block('ort',2,170,.3)]*2
    assert eligible(b,c)
    for changes in ({'parity':False},{'functional_parity':False},{'overhead_validated':False},{'cpu_per_frame':.8},{'synthetic_p95':181},{'synthetic_p95':float('nan')}):
        assert not eligible(b,[c[0]|changes,c[1]|changes])
    assert not eligible(b,[])
def test_selection():
    blocks=[block(b,n,240 if b=='ocv' else 170,.5 if b=='ocv' else .2) for b,n in order(4)]
    assert select(blocks,4)==2
    assert select([x|{'cpu_per_frame':.1} if x['backend']=='ort' and x['threads']==4 else x for x in blocks],4)==4
    assert select([x|{'parity':False} for x in blocks],4) is None
    with pytest.raises(ValueError):select(blocks[:-1],4)
def test_overhead():
    assert paired_overhead([100,100],[104,105])['pass_gate']
    assert not paired_overhead([100,100],[106,110])['pass_gate']
    with pytest.raises(ValueError):paired_overhead([0],[1])
def test_reconcile():
    assert reconcile(12,10,{'decode':2,'infer':7})=={'child_residual_ms':1,'transport_residual_ms':2}
    with pytest.raises(ValueError):reconcile(5,10,{'decode':2})
    with pytest.raises(ValueError):reconcile(12,10,{'decode':11})
@pytest.mark.parametrize('fn',[screening,_screening_design])
def test_screening_guard(fn):
    with pytest.raises(RuntimeError):asyncio.run(fn(None))

def det(label='car',score=.9,box=(.3,.2,.5,.4)):
    from src.vision.contracts import Detection
    return Detection(label=label,confidence=score,xyxy=box)

def test_pairing_and_tolerance():
    a,b=det(),det('bus',.8)
    assert matched_differences([a,b],[b,a])=={'match':True,'box_max':0.,'score_max':0.}
    assert matched_differences([a],[det(score=.90009)])['match']
    assert not matched_differences([a],[det(score=.90011)])['match']
    assert not matched_differences([a],[b])['match']
    assert not matched_differences([a],[])['match']

def raw_prediction(score):
    import numpy as np
    raw=np.zeros((1,8400,85),np.float32);i=40*80+40
    raw[0,i,:4]=[0,0,math.log(5),math.log(5)];raw[0,i,4]=1;raw[0,i,7]=score
    return raw

def test_real_decoder_confidence_boundary():
    import numpy as np
    from src.vision.yolo import decode_yolox
    below=np.nextafter(np.float32(.25),np.float32(0))
    above=np.nextafter(np.float32(.25),np.float32(1))
    assert len(decode_yolox(raw_prediction(below),(1,640,640)))==0
    assert len(decode_yolox(raw_prediction(.25),(1,640,640)))==1
    assert len(decode_yolox(raw_prediction(above),(1,640,640)))==1

def test_real_nms_boundaries_and_ties():
    from src.vision.yolo import _nms,_iou
    a=det(box=(.1,.1,.5,.5));b=det(box=(.2,.1,.6,.5))
    threshold=_iou(a,b)
    assert _nms([a,b],threshold)==(a,b)
    assert _nms([a,b],threshold-1e-9)==(a,)
    assert _nms([b,a],threshold-1e-9)==(b,)
    assert len(_nms([a,det('bus',box=a.xyxy)],.45))==2

def test_real_decoder_rejects_invalid():
    import numpy as np
    from src.vision.yolo import decode_yolox
    bad=raw_prediction(.9);bad[0,0,4]=np.nan
    with pytest.raises(ValueError):decode_yolox(bad,(1,640,640))
    bad=raw_prediction(.9);bad[0,0,4]=1.1
    with pytest.raises(ValueError):decode_yolox(bad,(1,640,640))
    with pytest.raises(ValueError):decode_yolox(np.zeros((1,5,85)),(1,640,640))

def test_adapter_reuses_exact_decoder_with_fake_forward():
    import numpy as np
    from types import SimpleNamespace
    from src.vision.yolo import preprocess_yolox,decode_yolox
    class FakeNet:
        def setInput(self,blob):self.blob=blob
        def forward(self):return raw_prediction(.9)
        def run(self,names,inputs):self.blob=inputs['x'];return [raw_prediction(.9)]
    image=np.zeros((240,320,3),np.uint8);blob,geo=preprocess_yolox(image);expect=decode_yolox(raw_prediction(.9),geo)
    for backend in ('ocv','ort'):
        d=Detector.__new__(Detector);d.backend=backend;d.net=FakeNet();d.input='x';d.output='y';d.spec=SimpleNamespace(confidence=.25,nms_iou=.45)
        got,stages=d.infer(image);assert got==expect;assert np.array_equal(d.net.blob,blob)
        assert set(stages)=={'preprocess_ms','forward_ms','postprocess_ms'}
        assert d.infer(image,False)==(expect,{})

def test_real_tracking_analytics_fixture():
    from types import SimpleNamespace
    spec=SimpleNamespace(sha256=MODEL,purpose='validation_only',confidence=.25)
    seq=[(det(box=(.3,.15+i*.018,.5,.35+i*.018)),) for i in range(32)]*3
    timing=[];a=functional_trace(seq,spec,timing);b=functional_trace(seq,spec)
    assert len(a)==len(timing)==96 and a==b
    assert a[31]['analytics']['lines'][0]['negative_to_positive']==1
    assert a[31]['analytics']['discontinuities']==0
    assert a[31]['tracking']['tracks'][0]['state']=='confirmed'
    assert all(x['tracking_service_ms']>=0 and x['analytics_service_ms']>=0 for x in timing)
    changed=list(seq);changed[1]=()
    assert functional_trace(changed,spec)!=a
