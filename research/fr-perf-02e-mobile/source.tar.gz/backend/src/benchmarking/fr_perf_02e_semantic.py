"""Prospective diagnostic, never eligibility or operational acceptance.
Only accepts inputs and regenerates the original three-segment replay.
"""
from fractions import Fraction as F
import math
from hashlib import sha256
from src.benchmarking.fr_perf_02e_diag import SPEC, compare_traces, detection_track_links
from src.benchmarking.fr_perf_02c import functional_trace
from src.vision.contracts import Detection
from src.analytics.contracts import SourceGeometry

LIMIT=F(1,10000) # prior detector tolerance, not fit to observed holdout differences
ARITHMETIC_CAP=F(1,10**9) # percentage points; reject if exact oracle error exceeds cap
GEOMETRY=SourceGeometry.model_validate(dict(source_id='FR_PERF_LAB',intersection_code='FR_PERF_LAB',regions=[dict(region_id='lab',xyxy=[.1,.1,.9,.9])],lines=[dict(line_id='lab_line',start=[.1,.5],end=[.9,.5])]))

def rational_box(b):
    if len(b)!=4 or any(type(x) not in (float,int) or not math.isfinite(x) for x in b): raise ValueError('invalid box')
    a=tuple(F(x) for x in b)
    if not (0<=a[0]<a[2]<=1 and 0<=a[1]<a[3]<=1): raise ValueError('invalid box')
    return a

def intersection(a,b):
    if a is None or b is None: return None
    c=max(a[0],b[0]),max(a[1],b[1]),min(a[2],b[2]),min(a[3],b[3])
    return c if c[0]<c[2] and c[1]<c[3] else None

def area(a): return (a[2]-a[0])*(a[3]-a[1]) if a else F(0)

def union(boxes):
    """Exact independent cell sweep (rational representations of binary floats)."""
    boxes=[b for b in boxes if b is not None]
    xs=sorted({x for b in boxes for x in (b[0],b[2])}); total=F(0)
    for x,y in zip(xs,xs[1:]):
        spans=sorted((b[1],b[3]) for b in boxes if b[0]<=x and b[2]>=y)
        if not spans: continue
        lo,hi=spans[0]; length=F(0)
        for l,h in spans[1:]:
            if l>hi: length+=hi-lo;lo,hi=l,h
            else: hi=max(hi,h)
        total+=(y-x)*(length+hi-lo)
    return total

def coverage_check(left,right,roi,reported_left,reported_right):
    if set(left)!=set(right): raise ValueError('confirmed set changed')
    r=rational_box(roi)
    a=[intersection(rational_box(left[k]),r) for k in sorted(left)]
    b=[intersection(rational_box(right[k]),r) for k in sorted(left)]
    exact_a=100*union(a)/area(r); exact_b=100*union(b)/area(r)
    if any(type(x) is not float or not math.isfinite(x) or not 0<=x<=100 for x in (reported_left,reported_right)): raise ValueError('invalid reported coverage')
    err_a=abs(F(reported_left)-exact_a);err_b=abs(F(reported_right)-exact_b)
    bound=100*sum((area(x)+area(y)-2*area(intersection(x,y)) for x,y in zip(a,b)),F(0))/area(r)
    delta=abs(F(reported_left)-F(reported_right))
    return dict(pass_bound=err_a<=ARITHMETIC_CAP and err_b<=ARITHMETIC_CAP and delta<=bound+err_a+err_b,
                delta=float(delta),bound=float(bound),oracle_errors=[float(err_a),float(err_b)])

def diagnose(reference,candidate):
    """Fail closed; compute actual trace from typed synthetic inputs, not provided flags."""
    result=dict(scope='prospective_semantic_diagnostic_only',original_screening='NO_ELIGIBLE_CANDIDATE',candidate_promoted=False,physical_actuation=False,phase_b='DEFERRED',human_acceptance='PENDING_HUMAN',semantic_diagnostic_pass=False)
    reasons=[]; result['reasons']=reasons
    try:
        if len(reference)!=96 or len(candidate)!=96: raise ValueError('expected 96 frames')
        a=[tuple(Detection.model_validate(d) for d in ds) for ds in reference]
        b=[tuple(Detection.model_validate(d) for d in ds) for ds in candidate]
        if not any(a) or not any(b): reasons.append('empty_reference_or_candidate')
        for i,(x,y) in enumerate(zip(a,b)):
            def near(u,v): return u.label==v.label and max(abs(F(p)-F(q)) for p,q in zip(u.xyxy,v.xyxy))<=LIMIT and abs(F(u.confidence)-F(v.confidence))<=LIMIT
            pairs=[[j for j,v in enumerate(y) if near(u,v)] for u in x]
            if len(x)!=len(y) or any(len(js)!=1 for js in pairs) or len({js[0] for js in pairs})!=len(x): reasons.append(f'input_ambiguous_or_unmatched:{i}')
            elif any(js[0]!=k for k,js in enumerate(pairs)): reasons.append(f'input_order_changed:{i}')
        x=functional_trace(a,SPEC); y=functional_trace(b,SPEC)
        diff=compare_traces(x,y);result['original_exact_equal']=diff['exact_equal'];result['differences']=diff['counts'];result['max_continuous_delta']=diff['max_continuous_delta']
        if any(z['kind']!='continuous' for z in diff['differences']): reasons.append('strict_field_difference')
        for z in diff['differences']:
            if z['kind']=='continuous' and '/image_coverage_pct' not in z['path'] and abs(F(z['reference'])-F(z['candidate']))>LIMIT: reasons.append('continuous_track_limit:'+z['path'])
        links=detection_track_links(a,b,x,y);result['link_differences']=links
        if links: reasons.append('ambiguous_or_changed_track_link')
        checks=[]; geometry_hash=sha256(GEOMETRY.model_dump_json().encode()).hexdigest()
        for i,(u,v) in enumerate(zip(x,y)):
            for t in (u,v):
                tr=t['tracking']; an=t['analytics']
                if any(tr[k]!=an[k] for k in ('source_id','intersection_code','session_id','tracking_epoch','frame_sequence','model_sha256','purpose','received_at')) or an['geometry_sha256']!=geometry_hash: raise ValueError('lineage mismatch')
                if len({z['track_id'] for z in tr['tracks']})!=len(tr['tracks']): raise ValueError('duplicate id')
            def confirmed(t): return {z['track_id']:z['xyxy'] for z in t['tracking']['tracks'] if z['state']=='confirmed'}
            if set(confirmed(u))!=set(confirmed(v)):
                reasons.append(f'confirmed_set_changed:{i}');continue
            for r,aa,bb in zip(GEOMETRY.regions,u['analytics']['regions'],v['analytics']['regions'],strict=True):
                if aa['region_id']!=r.region_id or bb['region_id']!=r.region_id: raise ValueError('ROI mismatch')
                c=coverage_check(confirmed(u),confirmed(v),r.xyxy,aa['image_coverage_pct'],bb['image_coverage_pct']);checks.append(dict(frame=i,region=r.region_id,**c))
                if not c['pass_bound']: reasons.append(f'coverage_bound:{i}:{r.region_id}')
        result['coverage_checks']=checks
        result['semantic_diagnostic_pass']=not reasons
    except (ValueError,TypeError,KeyError,IndexError,ArithmeticError) as e:
        reasons.append('invalid_or_inconclusive:'+type(e).__name__+':'+str(e)[:160])
    return result
