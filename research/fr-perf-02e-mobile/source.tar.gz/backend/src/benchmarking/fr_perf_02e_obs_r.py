"""Amended research observation draft only; no eligibility, no operational actuation.
No network on import, no media before a same-run fixture proof. Private inputs only.
"""
import argparse, asyncio, hashlib, json, math, os, re, sys, time
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree
from urllib.parse import urlencode
from urllib.request import Request, build_opener, HTTPRedirectHandler
from src.benchmarking import fr_perf_02c as c
from src.benchmarking.fr_perf_02e_semantic import diagnose
from src.benchmarking.fr_perf_02e_diag import compare_traces
from src.vision.contracts import ModelSpec

BRANCH='refs/heads/research/fr-perf-02e-obs'
FILE='Video_Codec_Test_rush_hour_1080p25.y4m.webm'
REVISION=1174135939
SHA1='a80ae4df93bc2b24004ca1f850e4b1e3e666a603'
SIZE=14122530
URL='https://upload.wikimedia.org/wikipedia/commons/a/a3/'+FILE
INDICES=tuple(range(0,480,5))
SCHEDULE=('ocv','ort','ort','ocv')
FIXED={'prospective-inputs.json':'7b9011bc29dbb67e3de43dc0f984936fbe8549197097a2196d5e8321f842ea7e','boundary-inputs.json':'c594088f7865314ffd0d975fbe77908166e7849960e22d35e17bd745e053e12e'}
SOURCE_WIDTH=1920
SOURCE_HEIGHT=1080
TARGET_WIDTH=1280
TARGET_HEIGHT=720
ADENDUM='FR-PERF-02E-OBS-R-v1'
# No authenticated content-review mechanism is connected to this draft.
# Deliberately fail closed, never generate an approval from a flag.
def review_channel():
    raise ValueError('PRIVACY_REVIEW_CHANNEL_UNAVAILABLE: authenticated content review required')
FLAGS=dict(original_screening='NO_ELIGIBLE_CANDIDATE',candidate_promoted=False,physical_actuation=False,phase_b='DEFERRED',human_acceptance='PENDING_HUMAN',operational_decision='abstain',field_ready=False)

def identity():
    if (os.environ.get('GITHUB_ACTIONS'),os.environ.get('GITHUB_REF'),os.environ.get('GITHUB_RUN_ATTEMPT'),os.environ.get('GITHUB_EVENT_NAME'))!=('true',BRANCH,'1','workflow_dispatch'):
        raise ValueError('isolated first-attempt workflow required')
    sha=os.environ.get('GITHUB_SHA',''); run=os.environ.get('GITHUB_RUN_ID','')
    if not re.fullmatch('[0-9a-f]{40}',sha) or not run.isdigit(): raise ValueError('run identity')
    return dict(revision=sha,run_id=run,attempt=1,branch=BRANCH)

def private(p):
    p=Path(p).resolve()
    if not p.is_relative_to(Path('/tmp')) or any((a/'.git').exists() for a in (p,*p.parents)):
        raise ValueError('private output outside checkout required')
    return p

def read_proof(path):
    d=json.loads(Path(path).read_text());h=d.pop('report_sha256',None)
    if h!=c.digest(json.dumps(d,sort_keys=True,separators=(',',':'),allow_nan=False).encode()): raise ValueError('proof hash')
    return d

def frozen(root):
    for n,h in FIXED.items():
        if c.digest((Path(root)/n).read_bytes())!=h:raise ValueError('frozen oracle mismatch')
    return FIXED.copy()

def verify_source_contract():
    """Authorized fixed transformation; no change to worker limits."""
    from src.video.contracts import MAX_WIDTH,MAX_HEIGHT
    if (SOURCE_WIDTH,SOURCE_HEIGHT,TARGET_WIDTH,TARGET_HEIGHT)!=(1920,1080,1280,720) or TARGET_WIDTH>MAX_WIDTH or TARGET_HEIGHT>MAX_HEIGHT:
        raise ValueError('SOURCE_RESOLUTION_BLOCKED: amended dimensions incompatible')
    return dict(adendum=ADENDUM,source=[1920,1080],target=[1280,720],interpolation='INTER_AREA',jpeg_quality=90)

def setup(a):
    verify_source_contract()
    review_channel()
    c.verify_environment(a.lock);c.verify_acquisition_lock(a.acquisition_lock)
    if sys.version_info[:3]!=(3,12,16):raise ValueError('exact Python version')
    frozen(a.oracles);ident=identity()
    from src.benchmarking.si10_cpu_profile import cpu_budget
    if cpu_budget()['thread_budget']<2:raise ValueError('insufficient CPU')
    spec=ModelSpec.model_validate_json(a.model_spec.read_text())
    if c.digest(spec.resolve(a.model_root).read_bytes())!=c.MODEL or spec.sha256!=c.MODEL or spec.purpose!='validation_only' or spec.architecture!='yolox' or (spec.confidence,spec.nms_iou)!=(.25,.45):raise ValueError('model contract')
    return ident,spec

def expected_fixture(a):
    return c.load_inputs(a.inputs)['synthetic'][:4]

def junit_count(path):
    t=ElementTree.parse(path).getroot();suites=[t] if t.tag=='testsuite' else list(t.findall('testsuite'))
    count=sum(int(s.attrib['tests']) for s in suites)
    if count<86 or any(int(s.attrib.get(k,0)) for s in suites for k in ('failures','errors','skipped')):raise ValueError('fixture tests incomplete')
    return count

async def fixtures(a):
    ident,spec=setup(a);n=junit_count(a.junit)
    from src.benchmarking.fr_perf_01a import synthetic_frames
    src=synthetic_frames();frames=[src[k] for k in c.SLOTS[:4]];del src
    hashes=[c.digest(f) for f in frames]
    if hashes!=expected_fixture(a):raise ValueError('fixture frame identity')
    arms=[];r=dict(scope='fr02e_target_fixtures_no_media',identity=ident,lock_sha256=c.LOCK_SHA256,acquisition_lock_sha256=c.ACQUISITION_LOCK_SHA256,model_sha256=c.MODEL,oracles=FIXED,adendum=ADENDUM,tests=n,arms=arms,passed=False,environment=c.runtime_info(),**FLAGS)
    try:
        async with asyncio.timeout(110):
            for backend in ('ocv','ort'):
                arm=dict(backend=backend,threads=2,blocks=[],plain_profile_parity=False);arms.append(arm);outputs=[]
                for mode in (False,True):
                    rows=[];arm['blocks'].append(dict(profile=mode,rows=rows))
                    ds,cpu,parent=await c.block(spec,a.model_root,backend,2,frames,mode,rows);outputs.append(ds)
                    c.verify_rows(rows,hashes);arm['blocks'][-1].update(cpu_per_frame=cpu,parent_cpu_per_frame=parent)
                arm['plain_profile_parity']=all(c.matched_differences(x,y)['match'] for x,y in zip(*outputs)) and len(outputs[0])==len(outputs[1])==4
                if not arm['plain_profile_parity']:raise ValueError('fixture IPC parity failed')
        r['passed']=True
    except BaseException as e:
        r['error_type']=type(e).__name__;raise
    finally:c.save(private(a.output),r)

def gate(a):
    if not a.authorize_observation or not a.authorize_source:raise ValueError('explicit authorization required')
    ident,spec=setup(a);p=read_proof(a.fixture_proof)
    expect=dict(scope='fr02e_target_fixtures_no_media',identity=ident,lock_sha256=c.LOCK_SHA256,acquisition_lock_sha256=c.ACQUISITION_LOCK_SHA256,model_sha256=c.MODEL,oracles=FIXED,adendum=ADENDUM,passed=True,**FLAGS)
    if any(p.get(k)!=v for k,v in expect.items()) or type(p.get('tests')) is not int or p['tests']<86:raise ValueError('fixture proof identity or gate')
    if [(x['backend'],x['threads']) for x in p['arms']]!=[('ocv',2),('ort',2)]:raise ValueError('fixture arms')
    hashes=expected_fixture(a)
    for arm in p['arms']:
        if arm['plain_profile_parity'] is not True or [b['profile'] for b in arm['blocks']]!=[False,True]:raise ValueError('fixture mode gate')
        for b in arm['blocks']:
            c.verify_rows(b['rows'],hashes)
            if not all(x['profile']==b['profile'] for x in b['rows']):raise ValueError('fixture mode mismatch')
    return ident,spec

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):raise ValueError('unexpected redirect')

def fetch(url,limit,seconds=30):
    start=time.monotonic(); data=bytearray()
    opener=build_opener(NoRedirect())
    req=Request(url,headers={'User-Agent':'FR-PERF-02E-OBS/1.0 (research; https://github.com/LucaSoares87/sem-foro_inteligente/issues/46)'})
    with opener.open(req,timeout=min(seconds,20)) as response:
        if response.geturl()!=url or response.status!=200:raise ValueError('unexpected source response')
        while True:
            if time.monotonic()-start>=seconds:raise TimeoutError('source timeout')
            chunk=response.read(min(65536,limit+1-len(data)))
            if not chunk:break
            data.extend(chunk)
            if len(data)>limit:raise ValueError('source size cap')
    return bytes(data)

def verify_metadata(data):
    pages=data['query']['pages']
    if len(pages)!=1:raise ValueError('source metadata pages')
    p=pages[0]; ii=p['imageinfo']
    if p['title'].replace(' ','_')!='File:'+FILE or len(ii)!=1 or p['revisions'][0]['revid']!=REVISION:raise ValueError('source revision mismatch')
    i=ii[0]; checksum=i['sha1'].lower()
    if len(checksum)!=40:checksum=f'{int(checksum,36):040x}'
    ext=i['extmetadata']; license_url=ext['LicenseUrl']['value'].rstrip('/')
    if (checksum,i['size'],i['width'],i['height'],i['mime'],i['url'])!=(SHA1,SIZE,1920,1080,'video/webm',URL) or license_url not in ('https://creativecommons.org/publicdomain/zero/1.0','http://creativecommons.org/publicdomain/zero/1.0') or ext['LicenseShortName']['value']!='CC0':raise ValueError('source identity or license mismatch')
    return dict(source=FILE,revision=REVISION,url=URL,sha1=SHA1,size=SIZE,license='CC0 1.0',width=1920,height=1080,mime='video/webm')

def verify_bytes(raw):
    if len(raw)!=SIZE or hashlib.sha1(raw).hexdigest()!=SHA1:raise ValueError('source bytes mismatch')
    return c.digest(raw)

def verify_privacy_plan(path,ident):
    # A reviewed processing plan is NOT a certification of absence of people/plates.
    p=read_proof(path)
    expect=dict(scope='fr02e_privacy_plan',identity=ident,source_sha1=SHA1,restricted_processing_approved=True,raw_media_export=False,identification=False,aggregate_and_hash_only=True)
    if any(p.get(k)!=v for k,v in expect.items()):raise ValueError('privacy processing plan pending')
    return p

def verify_privacy_review(path,ident,source_hash,plan_hash):
    # Separate assessment before inference; no auto-generated content approval.
    p=read_proof(path)
    expect=dict(scope='fr02e_privacy_review',identity=ident,source_sha1=SHA1,source_sha256=source_hash,privacy_plan_sha256=plan_hash,restricted_processing_approved=True,reviewed_content=True)
    if any(p.get(k)!=v for k,v in expect.items()):raise ValueError('privacy content review pending')
    return p

def acquire(a):
    ident,_=gate(a) # must happen before even requesting source metadata
    verify_privacy_plan(a.privacy_plan,ident)
    q=urlencode(dict(action='query',revids=REVISION,prop='revisions|imageinfo',rvprop='ids',iiprop='url|sha1|size|mime|extmetadata',format='json',formatversion=2))
    meta=verify_metadata(json.loads(fetch('https://commons.wikimedia.org/w/api.php?'+q,1024*1024)))
    raw=fetch(URL,15*1024*1024,90);h=verify_bytes(raw)
    p=private(a.media);p.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(raw)
    c.save(private(a.source_proof),dict(scope='fr02e_source_verified',identity=ident,**meta,sha256=h,privacy_plan_sha256=c.digest(a.privacy_plan.read_bytes()),**FLAGS))

def transform(img):
    """Single deterministic resize and JPEG; exact input/target contract."""
    import cv2, numpy as np
    from src.video.contracts import MAX_JPEG
    verify_source_contract()
    if not isinstance(img,np.ndarray) or img.shape!=(SOURCE_HEIGHT,SOURCE_WIDTH,3) or img.dtype!=np.uint8:
        raise ValueError('source pixel contract')
    original=c.digest(img.tobytes(order='C'))
    target=cv2.resize(img,(TARGET_WIDTH,TARGET_HEIGHT),interpolation=cv2.INTER_AREA)
    if target.shape!=(TARGET_HEIGHT,TARGET_WIDTH,3) or target.dtype!=np.uint8:
        raise ValueError('resized pixel contract')
    ok,jpeg=cv2.imencode('.jpg',target,[cv2.IMWRITE_JPEG_QUALITY,90])
    if not ok or not 0<len(jpeg)<=MAX_JPEG:raise ValueError('JPEG contract')
    raw=jpeg.tobytes()
    return raw,dict(original_pixels_sha256=original,resized_pixels_sha256=c.digest(target.tobytes(order='C')),jpeg_sha256=c.digest(raw))

def decode(p):
    verify_source_contract()
    import cv2
    cap=cv2.VideoCapture(str(p));frames=[];records=[];prev=None
    try:
        fps=cap.get(cv2.CAP_PROP_FPS)
        if not cap.isOpened() or not math.isfinite(fps) or abs(fps-25)>1e-6:raise ValueError('source fps mismatch')
        for i in range(476):
            ok,img=cap.read();t=cap.get(cv2.CAP_PROP_POS_MSEC)/1000
            if not ok or img is None or img.shape!=(SOURCE_HEIGHT,SOURCE_WIDTH,3) or not math.isfinite(t) or t<0 or (prev is not None and abs(t-prev-.04)>.002):raise ValueError('source decode or cadence mismatch')
            if i==0:start=t
            if abs(t-start-i*.04)>.002:raise ValueError('source cumulative cadence mismatch')
            prev=t
            if i in INDICES:
                raw,hashes=transform(img);frames.append(raw);records.append(dict(index=i,timestamp=t,**hashes))
    finally:cap.release()
    verify_manifest(frames,records)
    return frames,records

def verify_manifest(frames,records):
    if len(frames)!=96 or len(records)!=96 or tuple(r['index'] for r in records)!=INDICES:raise ValueError('input count or order')
    t0=records[0]['timestamp']
    for f,r,i in zip(frames,records,INDICES,strict=True):
        if not math.isfinite(r['timestamp']) or r['timestamp']<0 or abs(r['timestamp']-t0-i*.04)>.002:raise ValueError('manifest cadence')
        for k in ('original_pixels_sha256','resized_pixels_sha256','jpeg_sha256'):
            if not re.fullmatch('[a-f0-9]{64}',r[k]):raise ValueError('manifest hash format')
        if c.digest(f)!=r['jpeg_sha256']:raise ValueError('manifest JPEG identity')
    return [r['jpeg_sha256'] for r in records]

def compare(a,b,spec):
    if len(a)!=96 or len(b)!=96:raise ValueError('comparison incomplete')
    d=[c.matched_differences(x,y) for x,y in zip(a,b)]
    nonempty=[sum(bool(x) for x in a[i:i+32]) for i in (0,32,64)]
    x=c.functional_trace(a,spec);y=c.functional_trace(b,spec)
    s=diagnose(a,b);detail=compare_traces(x,y)
    # Only aggregated field categories, never values, coordinates, track IDs or imagery.
    paths=Counter(re.sub(r'/\d+(?=/|$)','/*',v['path']) for v in detail['differences'])
    reasons=Counter(r.split(':',1)[0] for r in s['reasons'])
    return dict(reference_nonempty_segments=nonempty,nonempty_gate=all(nonempty),detection_parity=all(z['match'] for z in d),differences=d,
        original_exact_equal=x==y,reference_functional_hash=c.digest(json.dumps(x,sort_keys=True).encode()),candidate_functional_hash=c.digest(json.dumps(y,sort_keys=True).encode()),semantic_diagnostic_pass=bool(all(nonempty) and s['semantic_diagnostic_pass']),semantic_reason_counts=dict(reasons),field_difference_counts=dict(paths),field_kind_counts=detail['counts'],max_continuous_delta=detail['max_continuous_delta'],link_status_counts=dict(Counter(z['status'] for z in s.get('link_differences',[]))),coverage_checks=len(s.get('coverage_checks',[])),coverage_failures=sum(not z['pass_bound'] for z in s.get('coverage_checks',[])))

async def observe(a):
    ident,spec=gate(a);p=read_proof(a.source_proof)
    if p.get('scope')!='fr02e_source_verified' or p.get('identity')!=ident or p.get('sha1')!=SHA1 or p.get('size')!=SIZE or p.get('privacy_plan_sha256')!=c.digest(a.privacy_plan.read_bytes()):raise ValueError('source proof')
    if verify_bytes(private(a.media).read_bytes())!=p['sha256']:raise ValueError('source digest changed')
    verify_privacy_plan(a.privacy_plan,ident)
    verify_privacy_review(a.privacy_review,ident,p['sha256'],p['privacy_plan_sha256'])
    out=private(a.output);out.mkdir(mode=0o700,exist_ok=False)
    frames,records=decode(a.media);hashes=verify_manifest(frames,records)
    c.save(out/'inputs.json',dict(scope='fr02e_frozen_inputs',identity=ident,source_sha256=p['sha256'],transform=verify_source_contract(),records=records,hashes=hashes,**FLAGS))
    report=dict(scope='fr02e_independent_observation_only',identity=ident,source_sha256=p['sha256'],input_hashes=hashes,blocks=[],pairs=[],determinism=[],complete=False,**FLAGS)
    outputs=[]
    try:
        async with asyncio.timeout(465):
            for idx,backend in enumerate(SCHEDULE):
                if verify_manifest(frames,records)!=hashes:raise ValueError("frozen inputs changed")
                rows=[];arm=dict(backend=backend,threads=2,index=idx,rows=rows,complete=False);report['blocks'].append(arm)
                try:
                    ds,cpu,parent=await c.block(spec,a.model_root,backend,2,frames,False,rows)
                    c.verify_rows(rows,hashes);outputs.append(ds)
                    arm.update(complete=True,cpu_per_frame=cpu,parent_cpu_per_frame=parent,detector=c.distribution([r['inference_ms'] for r in rows]),ipc=c.distribution([r['ipc_roundtrip_ms'] for r in rows]))
                finally:c.save(out/f'block-{idx}.json',arm)
            for i,j in ((0,1),(3,2)):
                report['pairs'].append(dict(reference_block=i,candidate_block=j,**compare(outputs[i],outputs[j],spec)))
            for i,j in ((0,3),(1,2)):
                report['determinism'].append(dict(backend=SCHEDULE[i],detection_hashes_equal=[r['detection_hash'] for r in report['blocks'][i]['rows']]==[r['detection_hash'] for r in report['blocks'][j]['rows']],**compare(outputs[i],outputs[j],spec)))
            report['complete']=True
            report['decision']='OBSERVATION_COMPLETE_NO_SELECTION'
    except BaseException as e:
        report['decision']='INCOMPLETE';report['error_type']=type(e).__name__;raise
    finally:c.save(out/'observation.json',report)

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('fixtures','verify','acquire','observe'))
    for k in ('lock','acquisition-lock','inputs','oracles','model-spec','model-root','output'):p.add_argument('--'+k,type=Path,required=True)
    for k in ('junit','fixture-proof','privacy-plan','privacy-review','media','source-proof'):p.add_argument('--'+k,type=Path)
    p.add_argument('--authorize-observation',action='store_true');p.add_argument('--authorize-source',action='store_true');a=p.parse_args()
    if a.mode=='fixtures':asyncio.run(fixtures(a))
    elif a.mode=='verify':gate(a)
    elif a.mode=='acquire':acquire(a)
    else:asyncio.run(observe(a))
if __name__=='__main__':main()
