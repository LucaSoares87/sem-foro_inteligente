"""Freeze independent synthetic inputs before evaluation; no media or model forward."""
import numpy as np
from src.benchmarking.fr_perf_02e_diag import det, tail, scenarios, gap_replay, compare_traces
from src.benchmarking.fr_perf_02e_semantic import diagnose
from src.vision.yolo import decode_yolox, _nms
from src.tracking.association import associate
from src.tracking.tracker import Track
from types import SimpleNamespace

def around(v):
    x=np.float32(v);return [float(np.nextafter(x,np.float32(-np.inf))),float(x),float(np.nextafter(x,np.float32(np.inf)))]

def pack(a): return [[d.model_dump(mode='json') for d in ds] for ds in a]

def independent_cases():
    # New geometry/trajectories, not the old Bellevue or diagnostic samples.
    a=[(det((.17,.14+i*.018,.31,.30+i*.018),.87,'truck'),det((.69,.70-i*.018,.85,.86-i*.018),.76,'motorcycle')) for i in range(32)]
    b=[tuple(det(tuple(v+2e-6 for v in d.xyxy),d.confidence-3e-6,d.label) for d in ds) for ds in a]
    yield 'new_stable_multiclass',a,b,True
    # Occlusion/reacquisition is the same on both arms; all inputs remain ordered.
    d=det((.29,.19,.47,.37),.82);e=det((.65,.58,.81,.74),.78,'bus')
    a=tail([(d,e),(d,e),(e,),(d,e),(d,e)]);b=tail([(d,e),(d,e),(e,),(d,e),(d,e)])
    yield 'occlusion_control',a,b,True
    b=tail([(d,e),(d,e),(d,e),(d,e),(d,e)])
    yield 'occlusion_difference',a,b,False
    a=tail([(d,d),(d,d)]);yield 'duplicate_ambiguous',a,a,False
    a=tail([(d,e),(d,e)]);b=tail([(e,d),(d,e)]);yield 'new_order_swap',a,b,False
    lo,mid,hi=around(.6)
    a=tail([(det((.21,.22,.41,.42),lo),)]);b=tail([(det((.21,.22,.41,.42),hi),)])
    yield 'confidence_neighbor',a,b,False
    a=tail([(d,),(d,)]);b=tail([(det(d.xyxy,d.confidence,'bus'),),(d,)])
    yield 'class_changed',a,b,False
    yield 'empty_vacuous',[()]*32,[()]*32,False
    a=tail([(d,),(d,)]);b=tail([(det(tuple(v+.0002 for v in d.xyxy),d.confidence),),(d,)])
    yield 'above_prior_tolerance',a,b,False

def decoder_cases():
    # One raw YOLOX cell with objectness=1, car score next to threshold.
    for s in around(.25):
        raw=np.zeros((1,8400,85),np.float32); raw[0,0,:4]=[40,40,3,3];raw[0,0,4]=1;raw[0,0,7]=s
        yield dict(name='decoder_confidence',score=s,actual=len(decode_yolox(raw,(1.,640,640))),expected=int(s>=.25))
    # NMS strict > .45; choose a fixed equal-width rectangle and FP32 neighboring shifts.
    a=det((.125,.25,.625,.75),.9);shift=.5*(1-.45)/(1+.45)
    for s in around(shift):
        b=det((.125+s,.25,.625+s,.75),.8)
        # exact rational oracle from stored float bounds, independent of implementation
        from fractions import Fraction as F
        from src.benchmarking.fr_perf_02e_semantic import rational_box,intersection,area
        x,y=rational_box(a.xyxy),rational_box(b.xyxy);inter=area(intersection(x,y));iou=inter/(area(x)+area(y)-inter)
        yield dict(name='nms_neighbor',shift=s,iou=float(iou),actual=len(_nms([a,b],.45)),expected=1 if iou>F(.45) else 2)
    a=det((.1,.1,.3,.3),.8);b=det((.7,.7,.9,.9),.8)
    yield dict(name='nms_stable_tie',actual=[d.xyxy for d in _nms([b,a],.45)],expected=[b.xyxy,a.xyxy])

def freeze():
    return dict(scope='synthetic_prospective_inputs',cases=[dict(name=n,reference=pack(a*3),candidate=pack(b*3),expected=e) for n,a,b,e in independent_cases()],regressions=[dict(name=n,reference=pack(a*3),candidate=pack(b*3),expected=n in ('identical_control','stable_fp32')) for n,a,b in scenarios()])

def evaluate(manifest):
    return dict(scope='local_synthetic_only',cases=[dict(name=c['name'],expected=c['expected'],**diagnose(c['reference'],c['candidate'])) for c in manifest['cases']+manifest['regressions']],decoder=list(decoder_cases()),gap=dict(control=compare_traces(gap_replay(),gap_replay())['exact_equal'],changed=not compare_traces(gap_replay(),gap_replay(True))['exact_equal']))

# Independent direct boundary fixtures; expected outcomes from rational geometry,
# not the implementation under test. No changes to previous frozen input manifest.
def boundary_manifest():
    return dict(iou=[dict(threshold=t,shift=s) for t in (.2,.3) for s in around(.5*(1-t)/(1+t))],
                confidence=around(.25),nms=around(.5*(1-.45)/(1+.45)),
                region=around(.1),deadband=around(.515),endpoint=around(.9),
                nms_equal_control=dict(box=[.125,.25,.625,.75],other=[.375,.25,.875,.75],threshold=1/3),
                gap_schedule=dict(control='gap_replay(False)',negative='gap_replay(True)',expected_control_epochs=[1,1,1,1,1,2,2,3,3]))

def boundary_results(m):
    from fractions import Fraction as F
    from src.benchmarking.fr_perf_02e_semantic import rational_box,intersection,area
    from src.analytics.geometry import contains,side,crosses_segment
    from src.analytics.contracts import CountingLine
    from src.tracking.association import associate
    from src.vision.yolo import _nms
    out=[];a=det((.125,.25,.625,.75),.9)
    for c in m['iou']:
        s,t=c['shift'],c['threshold'];b=det((.125+s,.25,.625+s,.75),.8)
        x,y=rational_box(a.xyxy),rational_box(b.xyxy);i=area(intersection(x,y));v=i/(area(x)+area(y)-i)
        track=SimpleNamespace(label=a.label,predicted_box=lambda:a.xyxy)
        pairs,missed,new=associate([track],[b],t)
        out.append(dict(name='association_iou',threshold=t,shift=s,iou=float(v),actual=bool(pairs),expected=v>=F(t)))
    line=CountingLine(line_id='new_line',start=(.1,.5),end=(.9,.5))
    for v in m['region']:
        out.append(dict(name='roi_boundary',value=v,actual=contains((.1,.1,.9,.9),(.5,v)),expected=F(v)>=F(.1)))
    for v in m['deadband']:
        # horizontal line -> signed vertical distance, use exact float representations
        d=F(v)-F(.5);e=1 if d>F(line.deadband) else -1 if d<-F(line.deadband) else 0
        out.append(dict(name='deadband_neighbor',value=v,actual=side(line,(.5,v)),expected=e))
    for v in m['endpoint']:
        out.append(dict(name='segment_endpoint',value=v,actual=crosses_segment(line,(v,.4),(v,.6)),expected=F(.1)<=F(v)<=F(.9)))
    c=m['nms_equal_control'];a=det(c['box'],.9);b=det(c['other'],.8)
    out.append(dict(name='nms_exact_runtime_equality_control',actual=len(_nms([a,b],c['threshold'])),expected=2))
    return out
