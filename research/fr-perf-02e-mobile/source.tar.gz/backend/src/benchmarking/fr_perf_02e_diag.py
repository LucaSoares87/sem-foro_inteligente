"""Offline diagnostic only; synthetic detections, no inference, no acceptance gate.
Reuses exact 02C replay plus a gap/session fixture with original services.
"""
import argparse
from collections import Counter
from datetime import datetime, timedelta, timezone
import json
import math
from pathlib import Path
import re
from types import SimpleNamespace
from uuid import UUID
import numpy as np
from src.benchmarking.fr_perf_02b import MODEL, matched_differences, digest, save
from src.benchmarking.fr_perf_02c import EpochIdentity, functional_trace
from src.vision.contracts import Detection, DetectionBatch
from src.tracking.service import TrackingService
from src.analytics.service import AnalyticsService
from src.analytics.contracts import SourceGeometry

# Synthetic stress magnitudes, chosen as decimal round numbers, not fit to holdouts.
# Actual deltas checked after FP32 casting; only input boxes and confidence are perturbed.
BOX_LIMIT=5.8e-7
SCORE_LIMIT=4.33e-6
SPEC=SimpleNamespace(sha256=MODEL,purpose='validation_only',confidence=.25)
CONTINUOUS=re.compile(r'^/(?:tracking/tracks/\d+/(?:confidence|xyxy/\d+)|analytics/regions/\d+/image_coverage_pct)$')

def field_diffs(a,b,path=''):
    """Report every unequal leaf/shape. Only known continuous fields are labeled.
    Integer, UUID, ordering, unexpected fields and type/length changes stay strict.
    No numeric tolerance applied to outputs. Not a new eligibility rule.
    """
    if type(a) is not type(b):
        yield dict(path=path or '/',kind='structural',reference=a,candidate=b); return
    if isinstance(a,dict):
        for k in sorted(a.keys()|b.keys()):
            p=path+'/'+k
            if k not in a or k not in b:
                yield dict(path=p,kind='structural',reference=a.get(k),candidate=b.get(k),missing_from='reference' if k not in a else 'candidate')
            else: yield from field_diffs(a[k],b[k],p)
    elif isinstance(a,list):
        if len(a)!=len(b):
            yield dict(path=path,kind='structural',reference_length=len(a),candidate_length=len(b))
        for i,(x,y) in enumerate(zip(a,b)):
            yield from field_diffs(x,y,path+'/'+str(i))
    elif a!=b:
        numeric=type(a) is float and bool(CONTINUOUS.fullmatch(path)) and math.isfinite(a) and math.isfinite(b)
        row=dict(path=path,kind='continuous' if numeric else 'strict',reference=a,candidate=b)
        if numeric: row['absolute_delta']=abs(a-b)
        yield row

def compare_traces(a,b):
    rows=[]
    if len(a)!=len(b): rows.append(dict(frame=None,path='/',kind='structural',reference_length=len(a),candidate_length=len(b)))
    for i,(x,y) in enumerate(zip(a,b)):
        rows.extend(dict(frame=i,**d) for d in field_diffs(x,y))
    maxima={}
    for d in rows:
        if d['kind']=='continuous':
            path=re.sub(r'/\d+(?=/|$)','/*',d['path'])
            maxima[path]=max(maxima.get(path,0.),d['absolute_delta'])
    return dict(exact_equal=a==b,counts=dict(Counter(x['kind'] for x in rows)),
                frames_different=len({x['frame'] for x in rows}),max_continuous_delta=maxima,differences=rows)

def det(box,score=.9,label='car'):
    return Detection(label=label,confidence=float(np.float32(score)),xyxy=tuple(float(np.float32(v)) for v in box))

def perturb(d,box_shift=0.,score_shift=0.):
    q=det(tuple(x+box_shift for x in d.xyxy),d.confidence+score_shift,d.label)
    assert max(abs(x-y) for x,y in zip(d.xyxy,q.xyxy))<=BOX_LIMIT
    assert abs(d.confidence-q.confidence)<=SCORE_LIMIT
    return q

def replace(frames,i,ds):
    out=list(frames);out[i]=tuple(ds);return out

def tail(frames):
    return list(frames)+[() for _ in range(32-len(frames))]

def scenarios():
    # Two spatially separated vehicles, away from decision thresholds, crossing line.
    stable=[(det((.24,.21+i*.018,.40,.37+i*.018),.88),det((.65,.66-i*.018,.81,.82-i*.018),.81,'bus')) for i in range(32)]
    yield 'identical_control',stable,stable
    yield 'stable_fp32',stable,[tuple(perturb(d,4e-7,4e-6) for d in ds) for ds in stable]
    # Confidence threshold .6 controls track creation. Both remain valid detector outputs.
    h=det((.3,.2,.5,.4),.600001)
    a=tail([(h,),(h,),(h,)]); b=tail([(perturb(h,score_shift=-2e-6),),(h,),(h,)])
    yield 'high_confidence_boundary',a,b
    # Low association threshold .20: established track and a low score detection.
    # Binary-exact geometry width .25; IoU .2 at shift .25*(2/3).
    base=det((.2,.2,.45,.45)); lo=det((.2+.25*2/3-2e-7,.2,.45+.25*2/3-2e-7,.45),.4)
    a=tail([(base,),(base,),(lo,)]);b=replace(a,2,[perturb(lo,4e-7)])
    yield 'low_iou_boundary',a,b
    # High-pass IoU .30: box width .26, horizontal shift .14.
    base=det((.2,.2,.46,.46)); edge=det((.34-2e-7,.2,.60-2e-7,.46))
    a=tail([(base,),(edge,)]); b=replace(a,1,[perturb(edge,4e-7)])
    yield 'high_iou_boundary',a,b
    # Foot barely inside ROI lower boundary .1. Confirmed visibility is discrete.
    d=det((.35,.02,.55,.1000002)); a=tail([(d,),(d,)]); b=replace(a,1,[perturb(d,-4e-7)])
    yield 'region_boundary',a,b
    # Counting line y=.5, deadband .015: move from below to just beyond positive side.
    d0=det((.35,.27,.55,.47));d1=det((.35,.3150002,.55,.5150002))
    a=tail([(d0,),(d0,),(d1,)]);b=replace(a,2,[perturb(d1,-4e-7)])
    yield 'line_deadband_boundary',a,b
    # Crossing intersection at endpoint x=.9. Same IDs may have different line counts.
    e0=det((.7999998,.28,.9999998,.48)); e1=det((.7999998,.32,.9999998,.52))
    # Shift only x within bounds, preserving input magnitude (x2 max 1).
    def shift_x(d):
        x1,y1,x2,y2=d.xyxy
        return det((x1+3e-7,y1,min(1.,x2+3e-7),y2),d.confidence)
    a=tail([(e0,),(e0,),(e1,)]); b=tail([(shift_x(e0),),(shift_x(e0),),(shift_x(e1),)])
    yield 'line_endpoint_boundary',a,b
    # Order perturbation not value perturbation: Hungarian parity is order-independent,
    # but new tracks are allocated in detection order. Distinct boxes make mapping observable.
    d1=det((.2,.2,.35,.35),.9);d2=det((.65,.65,.8,.8),.9)
    a=tail([(d1,d2),(d1,d2),(d1,d2)]);b=tail([(d2,d1),(d1,d2),(d1,d2)])
    yield 'detection_order',a,b
    # Equal assignment costs: two existing same-class tracks, symmetrically placed
    # relative to detections. Tiny horizontal shifts break equality in opposite directions.
    l=det((.25,.25,.55,.55));r=det((.45,.25,.75,.55)); top=det((.35,.2,.65,.5));bot=det((.35,.3,.65,.6))
    a=tail([(l,r),(l,r),(perturb(top,-2e-7),perturb(bot,2e-7))]);b=replace(a,2,[perturb(top,2e-7),perturb(bot,-2e-7)])
    yield 'assignment_near_tie',a,b

def gap_replay(change=False):
    """Extended fixture with real services, gap, session change, lost/reacquired track.
    Replay schedules are synthetic, not the original 96 frame cadence.
    """
    key='FR_PERF_LAB';stamp=datetime(2020,1,1,tzinfo=timezone.utc);session=UUID(int=1)
    video=SimpleNamespace(sessions={key:SimpleNamespace(session_id=session,state='ended')})
    vision=SimpleNamespace(video=video,spec=SPEC,state='ready',results={});vision.valid_result=vision.results.get
    tr=TrackingService(vision);vision.tracking=tr
    geom=SourceGeometry.model_validate(dict(source_id=key,intersection_code=key,regions=[dict(region_id='lab',xyxy=[.1,.1,.9,.9])],lines=[dict(line_id='lab_line',start=[.1,.5],end=[.9,.5])]))
    an=AnalyticsService(tr,{key:geom});tr.analytics=an;identity=EpochIdentity();result=[]
    d=det((.3,.2,.5,.4))
    schedule=[(1,1,0,True),(1,2,200,True),(1,3,400,False),(1,4,600,True),(1,7,1600,True),(1,8,3900,True),(1,9,4100,True),(2,1,4300,True),(2,2,4500,True)]
    if change: schedule[5]=(1,8,3500,True) # no >2s tracker reset, different timing/epoch
    for sid,seq,ms,visible in schedule:
        session=UUID(int=sid);video.sessions[key].session_id=session
        now=stamp+timedelta(milliseconds=ms)
        batch=DetectionBatch(source_id=key,intersection_code=key,session_id=session,frame_sequence=seq,received_at=now,inferred_at=now,model_sha256=MODEL,purpose=SPEC.purpose,inference_ms=0.,detections=(d,) if visible else ())
        vision.results[key]=batch;tr.consume(batch);t=tr.latest(key);a=an.latest(key)
        if tr.failed or an.failed or t is None or a is None: raise ValueError('replay failed')
        if (t.session_id,t.frame_sequence,t.model_sha256)!=(batch.session_id,batch.frame_sequence,batch.model_sha256): raise ValueError('lineage')
        result.append(identity.normalize(t.model_dump(mode='json'),a.model_dump(mode='json')))
    return result

def detection_track_links(a,b,x,y):
    """Map observations to unique synthetic detection pairs, without relabeling IDs.
    Ambiguous matching is explicitly unresolved, never interpreted as equivalence.
    This is an added diagnostic, not an acceptance criterion or ground truth metric.
    """
    rows=[]
    for i,(ref,cand,ta,tb) in enumerate(zip(a,b,x,y)):
        def near(d,e):
            return d.label==e.label and max(abs(u-v) for u,v in zip(d.xyxy,e.xyxy))<=1e-4 and abs(d.confidence-e.confidence)<=1e-4
        pairs=[[j for j,d in enumerate(cand) if near(r,d)] for r in ref]
        if any(len(js)!=1 for js in pairs) or len(ref)!=len(cand) or len({js[0] for js in pairs})!=len(ref):
            rows.append(dict(frame=i,status='ambiguous_or_unmatched_input'));continue
        def link(ds,trace):
            links={}
            for track in trace['tracking']['tracks']:
                hits=[k for k,d in enumerate(ds) if d.label==track['label'] and list(d.xyxy)==track['xyxy'] and d.confidence==track['confidence']]
                if len(hits)!=1 or hits[0] in links: return None
                links[hits[0]]=track['track_id']
            return links
        left=link(ref,ta);right=link(cand,tb)
        if left is None or right is None:
            rows.append(dict(frame=i,status='ambiguous_track_link'));continue
        for k,js in enumerate(pairs):
            j=js[0];u=left.get(k);v=right.get(j)
            if u!=v: rows.append(dict(frame=i,status='track_link_changed',reference_detection=k,candidate_detection=j,reference_track_id=u,candidate_track_id=v))
    return rows

def summarize_case(name,a,b):
    # Use exact 02C three-part replay, no altered comparator or production code.
    a=a*3;b=b*3
    p=[matched_differences(x,y) for x,y in zip(a,b)]
    x=functional_trace(a,SPEC);y=functional_trace(b,SPEC)
    assert functional_trace(a,SPEC)==x and functional_trace(b,SPEC)==y
    diff=compare_traces(x,y)
    links=detection_track_links(a,b,x,y)
    assert all(q['match'] and q['box_max']<=BOX_LIMIT and q['score_max']<=SCORE_LIMIT for q in p)
    return dict(name=name,scope='synthetic_diagnostic_only',nonempty=sum(bool(t) for t in a),
                detection_parity=all(q['match'] for q in p),input_max_box=max(q['box_max'] or 0 for q in p),input_max_score=max(q['score_max'] or 0 for q in p),
                reference_input=[[d.model_dump(mode='json') for d in ds] for ds in a],candidate_input=[[d.model_dump(mode='json') for d in ds] for ds in b],
                reference_trace=x,candidate_trace=y,track_link_differences=links,**diff)

def run():
    cases=[summarize_case(*s) for s in scenarios()]
    x=gap_replay(); y=gap_replay();assert x==y
    z=gap_replay(True)
    return dict(scope='local_synthetic_diagnostics_not_screening',screening_decision='NO_ELIGIBLE_CANDIDATE',physical_actuation=False,candidate_promoted=False,phase_b='DEFERRED',human_acceptance='PENDING_HUMAN',
                cases=cases,gap_control=dict(reference=x,candidate=y,**compare_traces(x,y)),gap_changed=dict(reference=x,candidate=z,**compare_traces(x,z)))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();save(a.output,run())
