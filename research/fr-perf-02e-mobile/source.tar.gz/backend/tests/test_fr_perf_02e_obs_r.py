import asyncio
from types import SimpleNamespace
import hashlib
from pathlib import Path
import numpy as np
import cv2
import pytest
from src.benchmarking import fr_perf_02e_obs_r as r
from src.benchmarking import fr_perf_02e_obs as old


def image():
    x=np.arange(1920,dtype=np.uint16)[None,:]
    y=np.arange(1080,dtype=np.uint16)[:,None]
    return np.stack([(x+y)%256,(2*x+y)%256,(x+3*y)%256],axis=2).astype(np.uint8)


def test_original_still_blocks_and_amended_contract():
    with pytest.raises(ValueError,match='SOURCE_RESOLUTION_BLOCKED'):old.verify_source_contract()
    assert r.verify_source_contract()['target']==[1280,720]


def test_resize_determinism_and_hashes():
    img=image();raw,record=r.transform(img);raw2,record2=r.transform(img.copy())
    assert raw==raw2 and record==record2
    target=cv2.resize(img,(1280,720),interpolation=cv2.INTER_AREA)
    ok,jpeg=cv2.imencode('.jpg',target,[cv2.IMWRITE_JPEG_QUALITY,90]);assert ok and raw==jpeg.tobytes()
    assert record==dict(original_pixels_sha256=hashlib.sha256(img.tobytes()).hexdigest(),resized_pixels_sha256=hashlib.sha256(target.tobytes()).hexdigest(),jpeg_sha256=hashlib.sha256(raw).hexdigest())
    assert cv2.imdecode(np.frombuffer(raw,np.uint8),cv2.IMREAD_COLOR).shape==(720,1280,3)


@pytest.mark.parametrize('img',[np.zeros((720,1280,3),np.uint8),np.zeros((1080,1920),np.uint8),np.zeros((1080,1920,3),np.float32)])
def test_invalid_input(img):
    with pytest.raises(ValueError,match='source pixel contract'):r.transform(img)


class Capture:
    def __init__(self,*,fps=25,fail=None,jitter=None,shift=0):
        self.fps=fps;self.fail=fail;self.jitter=jitter;self.shift=shift;self.i=-1;self.img=image();self.released=False
    def isOpened(self):return True
    def get(self,kind):
        if kind==cv2.CAP_PROP_FPS:return self.fps
        return self.i*40+self.shift+(5 if self.i==self.jitter else 0)
    def read(self):
        self.i+=1
        if self.i==self.fail:return False,None
        return True,self.img
    def release(self):self.released=True


def test_decode_and_frozen_manifest(monkeypatch):
    cap=Capture();monkeypatch.setattr(cv2,'VideoCapture',lambda p:cap)
    frames,records=r.decode(Path('/unused'));assert cap.released and cap.i==475
    assert len(frames)==96 and [x['index'] for x in records]==list(range(0,476,5))
    assert len(set(r.verify_manifest(frames,records)))==1
    assert records[-1]['timestamp']==19
    bad=frames.copy();bad[4]=b'changed'
    with pytest.raises(ValueError,match='JPEG identity'):r.verify_manifest(bad,records)
    swapped=records.copy();swapped[1],swapped[2]=swapped[2],swapped[1]
    with pytest.raises(ValueError,match='order'):r.verify_manifest(frames,swapped)
    badrecords=[dict(x) for x in records];badrecords[-1]['timestamp']+=.01
    with pytest.raises(ValueError,match='cadence'):r.verify_manifest(frames,badrecords)


@pytest.mark.parametrize('kwargs,match',[({'fps':24},'fps mismatch'),({'fail':2},'decode or cadence'),({'jitter':3},'decode or cadence')])
def test_capture_rejections(monkeypatch,kwargs,match):
    cap=Capture(**kwargs);monkeypatch.setattr(cv2,'VideoCapture',lambda p:cap)
    with pytest.raises(ValueError,match=match):r.decode(Path('/unused'))
    assert cap.released


def test_privacy_channel_blocks_before_setup_and_network(monkeypatch):
    def forbidden(*a,**kw):raise AssertionError('unexpected side effect')
    monkeypatch.setattr(r.c,'verify_environment',forbidden);monkeypatch.setattr(r,'fetch',forbidden)
    args=SimpleNamespace(authorize_observation=True,authorize_source=True)
    for f in (r.setup,r.gate,r.acquire):
        with pytest.raises(ValueError,match='PRIVACY_REVIEW_CHANNEL_UNAVAILABLE'):f(args)
    with pytest.raises(ValueError,match='PRIVACY_REVIEW_CHANNEL_UNAVAILABLE'):asyncio.run(r.fixtures(args))
    with pytest.raises(ValueError,match='PRIVACY_REVIEW_CHANNEL_UNAVAILABLE'):asyncio.run(r.observe(args))
