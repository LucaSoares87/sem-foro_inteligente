import asyncio, json
from pathlib import Path
from types import SimpleNamespace
import pytest
from src.benchmarking import fr_perf_02e_obs as o
from src.benchmarking.fr_perf_02e_fixtures import freeze
from src.vision.contracts import Detection
from src.benchmarking.fr_perf_02e_diag import SPEC

ROOT=Path(__file__).resolve().parents[2]

def test_static_resolution_blocks():
    with pytest.raises(ValueError,match='SOURCE_RESOLUTION_BLOCKED'):o.verify_source_contract()

def test_no_media_or_environment_before_static_gate(monkeypatch):
    def forbidden(*a,**kw):raise AssertionError('unexpected side effect')
    monkeypatch.setattr(o.c,'verify_environment',forbidden);monkeypatch.setattr(o,'fetch',forbidden)
    args=SimpleNamespace(authorize_observation=True,authorize_source=True)
    for f in (o.setup,o.gate,o.acquire):
        with pytest.raises(ValueError,match='SOURCE_RESOLUTION_BLOCKED'):f(args)
    with pytest.raises(ValueError,match='SOURCE_RESOLUTION_BLOCKED'):asyncio.run(o.fixtures(args))
    with pytest.raises(ValueError,match='SOURCE_RESOLUTION_BLOCKED'):asyncio.run(o.observe(args))
    with pytest.raises(ValueError,match='SOURCE_RESOLUTION_BLOCKED'):o.decode(Path('/nonexistent'))

def test_exact_source_metadata_and_reject_changed_fields():
    def meta():return {'query':{'pages':[{'title':'File:'+o.FILE.replace('_',' '),'revisions':[{'revid':o.REVISION}], 'imageinfo':[dict(sha1=o.SHA1,size=o.SIZE,width=1920,height=1080,mime='video/webm',url=o.URL,extmetadata={'LicenseUrl':{'value':'https://creativecommons.org/publicdomain/zero/1.0/'},'LicenseShortName':{'value':'CC0'}})]}]}}
    assert o.verify_metadata(meta())['sha1']==o.SHA1
    for key,val in [('width',1280),('size',1),('sha1','0'*40),('url','https://example.com/file.webm'),('mime','video/mp4')]:
        p=meta();p['query']['pages'][0]['imageinfo'][0][key]=val
        with pytest.raises(ValueError,match='identity or license'):o.verify_metadata(p)

def test_source_size_mismatch():
    with pytest.raises(ValueError,match='source bytes mismatch'):o.verify_bytes(b'fake')

def test_frozen_manifest_identity(tmp_path):
    assert o.frozen(ROOT/'evidence')==o.FIXED
    for n in o.FIXED:(tmp_path/n).write_bytes((ROOT/'evidence'/n).read_bytes())
    (tmp_path/'boundary-inputs.json').write_text('{}')
    with pytest.raises(ValueError,match='oracle mismatch'):o.frozen(tmp_path)

def test_exact_schedule():
    assert o.INDICES==tuple(range(0,476,5)) and len(o.INDICES)==96 and o.SCHEDULE==('ocv','ort','ort','ocv')

def test_compare_distinguishes_original_and_semantic():
    m=freeze()['cases'][0];a,b=([tuple(Detection.model_validate(d) for d in ds) for ds in m[k]] for k in ('reference','candidate'))
    r=o.compare(a,b,SPEC);assert r['nonempty_gate'] and r['detection_parity'] and r['semantic_diagnostic_pass'] and not r['original_exact_equal']
    assert 'differences' in r and all(set(d)=={'match','box_max','score_max'} for d in r['differences'])

def test_compare_never_approves_empty_or_short():
    r=o.compare([()]*96,[()]*96,SPEC);assert not r['semantic_diagnostic_pass'] and not r['nonempty_gate']
    with pytest.raises(ValueError,match='incomplete'):o.compare([()],[()],SPEC)

def test_reject_outside_runner(monkeypatch):
    monkeypatch.delenv('GITHUB_ACTIONS',raising=False)
    with pytest.raises(ValueError,match='isolated'):o.identity()

def test_privacy_proof_separate_from_license(tmp_path):
    ident={'run_id':'42','revision':'a'*40,'attempt':1,'branch':o.BRANCH}
    plan=tmp_path/'plan.json';o.c.save(plan,dict(scope='fr02e_privacy_plan',identity=ident,source_sha1=o.SHA1,restricted_processing_approved=True,raw_media_export=False,identification=False,aggregate_and_hash_only=True))
    assert o.verify_privacy_plan(plan,ident)['aggregate_and_hash_only']
    with pytest.raises(ValueError,match='privacy content review pending'):o.verify_privacy_review(plan,ident,'b'*64,o.c.digest(plan.read_bytes()))
    review=tmp_path/'review.json';o.c.save(review,dict(scope='fr02e_privacy_review',identity=ident,source_sha1=o.SHA1,source_sha256='b'*64,privacy_plan_sha256=o.c.digest(plan.read_bytes()),restricted_processing_approved=True,reviewed_content=True))
    assert o.verify_privacy_review(review,ident,'b'*64,o.c.digest(plan.read_bytes()))['reviewed_content']
    with pytest.raises(ValueError,match='privacy content review pending'):o.verify_privacy_review(review,ident,'c'*64,o.c.digest(plan.read_bytes()))
