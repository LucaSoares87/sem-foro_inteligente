from pathlib import Path
import json,hashlib
import pytest
from src.benchmarking.fr_perf_02e_fixtures import freeze,evaluate,boundary_manifest,boundary_results
from src.benchmarking.fr_perf_02e_semantic import coverage_check,diagnose,union,rational_box
from src.analytics.geometry import image_coverage
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2]/'evidence'

@pytest.fixture(scope='module')
def report():
    p=ROOT/'prospective-inputs.json';assert hashlib.sha256(p.read_bytes()).hexdigest()=='7b9011bc29dbb67e3de43dc0f984936fbe8549197097a2196d5e8321f842ea7e'
    m=json.loads(p.read_text());assert m==freeze();return evaluate(m)

@pytest.mark.parametrize('idx',range(19))
def test_frozen_semantic_oracles(report,idx):
    c=report['cases'][idx];assert c['semantic_diagnostic_pass']==c['expected'];assert c['candidate_promoted'] is False and c['original_screening']=='NO_ELIGIBLE_CANDIDATE'

def test_decoder_boundaries(report):
    assert len(report['decoder'])==7 and all(c['actual']==c['expected'] for c in report['decoder'])

def test_gap_epochs(report): assert report['gap']==dict(control=True,changed=True)

def test_direct_boundary_oracles():
    m=json.loads((ROOT/'boundary-inputs.json').read_text());assert m==boundary_manifest();r=boundary_results(m);assert len(r)==16 and all(c['actual']==c['expected'] for c in r)

def test_exact_union_overlap():
    assert union([rational_box([0.,0.,.5,.5]),rational_box([.25,.25,.75,.75])])==F(7,16)

def test_coverage_oracle_and_tamper():
    a={1:(.05,.05,.5,.5),2:(.25,.25,.8,.8)};b={1:(.05,.05,.50001,.5),2:a[2]};r=(.1,.1,.9,.9)
    x=image_coverage(r,list(a.values()));y=image_coverage(r,list(b.values()));assert coverage_check(a,b,r,x,y)['pass_bound']
    assert not coverage_check(a,b,r,x,y+.00001)['pass_bound']
    with pytest.raises(ValueError): coverage_check(a,{1:b[1]},r,x,y)
    with pytest.raises(ValueError): coverage_check(a,b,r,x,float('nan'))

def test_unknown_or_empty_input_fails_closed():
    assert not diagnose([],[])['semantic_diagnostic_pass']
    assert not diagnose([()] *96,[()]*96)['semantic_diagnostic_pass']
