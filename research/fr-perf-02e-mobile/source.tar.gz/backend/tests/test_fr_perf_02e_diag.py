import pytest
from src.benchmarking import fr_perf_02e_diag as d

@pytest.fixture(scope='module')
def report(): return d.run()

def test_control(report):
    a=report['cases'][0]; assert a['exact_equal'] and a['nonempty']==96 and not a['differences'] and not a['track_link_differences']

def test_stable_fp32(report):
    a=report['cases'][1];assert not a['exact_equal'] and set(a['counts'])=={'continuous'} and not a['track_link_differences']
    assert a['reference_trace'][31]['analytics']['lines']==a['candidate_trace'][31]['analytics']['lines']
    assert a['reference_trace'][31]['analytics']['lines'][0]['negative_to_positive']==1
    assert a['reference_trace'][31]['analytics']['lines'][0]['positive_to_negative']==1

@pytest.mark.parametrize('name,path',[('high_confidence_boundary','/analytics/tentative_visible'),('low_iou_boundary','/tracking/lost_private'),('high_iou_boundary','/tracking/tracks/0/state'),('region_boundary','/analytics/regions/0/confirmed_visible'),('line_deadband_boundary','/analytics/lines/0/negative_to_positive'),('line_endpoint_boundary','/analytics/lines/0/negative_to_positive')])
def test_boundary(report,name,path):
    a=next(x for x in report['cases'] if x['name']==name);assert a['detection_parity'] and not a['exact_equal']
    assert any(x['path']==path and x['kind']=='strict' for x in a['differences'])

@pytest.mark.parametrize('name',['detection_order','assignment_near_tie'])
def test_track_mapping(report,name):
    a=next(x for x in report['cases'] if x['name']==name); assert a['detection_parity'] and not a['exact_equal']
    assert any(x['status']=='track_link_changed' and x['reference_track_id'] is not None and x['candidate_track_id'] is not None and x['reference_track_id']!=x['candidate_track_id'] for x in a['track_link_differences'])

def test_input_limits(report):
    assert len(report['cases'])==10
    for a in report['cases']:
        assert a['detection_parity'] and a['input_max_box']<=d.BOX_LIMIT and a['input_max_score']<=d.SCORE_LIMIT and a['nonempty']>0
    assert report['screening_decision']=='NO_ELIGIBLE_CANDIDATE' and report['physical_actuation'] is False

def test_epochs_gap_and_loss(report):
    r=report['gap_control'];assert r['exact_equal']
    t=r['reference'];assert t[2]['tracking']['lost_private']==1
    assert t[4]['tracking']['skipped_frames']==2 and t[4]['analytics']['discontinuities']==1
    assert [x['tracking']['tracking_epoch'] for x in t]==[1,1,1,1,1,2,2,3,3]
    assert [x['analytics']['analytics_epoch'] for x in t]==[1,1,1,1,1,2,2,3,3]
    assert not report['gap_changed']['exact_equal']
    assert any(x['path']=='/tracking/tracking_epoch' for x in report['gap_changed']['differences'])

def test_type_and_shape_not_silently_normalized():
    a={'tracking':{'tracks':[{'track_id':1,'confidence':.9}]}}
    b={'tracking':{'tracks':[{'track_id':True,'confidence':.900001},{'track_id':2,'confidence':.9}]}}
    out=list(d.field_diffs(a,b));assert [x['kind'] for x in out].count('structural')==2
    assert any(x['kind']=='continuous' for x in out)

def test_ambiguous_links_fail_closed():
    a=d.det((.2,.2,.4,.4)); b=(a,a)
    r=d.detection_track_links([b],[b],[{}],[{}]);assert r==[{'frame':0,'status':'ambiguous_or_unmatched_input'}]
